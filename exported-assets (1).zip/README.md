# RAG-Enhanced GPT-OSS Inference System

A Retrieval-Augmented Generation (RAG) system integrated with OpenAI's GPT-OSS 20B model for OpenSCENARIO-aware code generation and assistance.

## Overview

This system combines:
- **RAG retrieval** from .osc scenario files and .md documentation
- **GPT-OSS 20B inference** for high-quality text generation
- **Smart context selection** based on query similarity
- **Interactive and batch processing modes**

## Features

- 🔍 **Intelligent Context Retrieval**: Searches .osc files by filename semantics and .md files by content
- 🤖 **GPT-OSS Integration**: Uses OpenAI's 20B parameter open-source model
- 📁 **File-based Knowledge Base**: Simple folder structure for scenarios and documentation
- ⚡ **Caching System**: Embeddings are cached for faster subsequent queries
- 🔄 **Live Document Refresh**: Update documents without restarting
- 💬 **Interactive Mode**: Continuous conversation interface

## Prerequisites

1. **Python Environment**: Python 3.8+ with conda
2. **GPT-OSS Repository**: Clone and set up the [gpt-oss-recipes](https://github.com/huggingface/gpt-oss-recipes) repository
3. **GPU Memory**: At least 16GB for GPT-OSS 20B model
4. **Dependencies**: Install from the gpt-oss-recipes environment

## Installation

### 1. Setup Base Environment

```bash
# Clone the gpt-oss-recipes repository
git clone https://github.com/huggingface/gpt-oss-recipes.git
cd gpt-oss-recipes

# Create and activate conda environment (follow their setup instructions)
conda create -n gpt-oss python=3.9
conda activate gpt-oss

# Install their requirements
pip install -r requirements.txt
```

### 2. Add RAG System

```bash
# Copy the RAG system files to your gpt-oss-recipes directory
# Place all .py files in the same directory as generate_all.py

# Install additional RAG dependencies
pip install sentence-transformers==2.2.2 scikit-learn>=1.3.0 nltk>=3.8
```

### 3. Setup Directories

```bash
# Create data and documentation directories
mkdir data doc embeddings

# Add your .osc files to the data/ folder
# Add your .md documentation files to the doc/ folder
```

## Directory Structure

```
your-project/
├── rag_inference.py          # Main script
├── rag_system.py            # RAG system core
├── document_processor.py    # Document handling
├── embedding_manager.py     # Embeddings and search
├── requirements.txt         # Additional dependencies
├── data/                    # Your .osc scenario files
│   ├── highway_merge.osc
│   ├── city_intersection.osc
│   └── ...
├── doc/                     # Your .md documentation
│   ├── openscenario_guide.md
│   ├── syntax_reference.md
│   └── ...
└── embeddings/             # Cached embeddings (auto-created)
    ├── osc_embeddings.pkl
    └── md_embeddings.pkl
```

## Usage

### Interactive Mode

```bash
python rag_inference.py
```

This starts an interactive session where you can:
- Ask questions about scenarios
- Request code generation
- Get documentation help
- Refresh documents with `refresh` command
- View system info with `info` command

### Single Query Mode

```bash
python rag_inference.py --query "Create a highway lane change scenario"
```

### Custom Configuration

```bash
python rag_inference.py \
    --model "openai/gpt-oss-20b" \
    --data-folder "my_scenarios" \
    --doc-folder "my_docs" \
    --max-tokens 1024 \
    --temperature 0.8
```

## Configuration Options

| Parameter | Default | Description |
|-----------|---------|-------------|
| `--model` | `openai/gpt-oss-20b` | GPT-OSS model path |
| `--data-folder` | `data` | Folder with .osc files |
| `--doc-folder` | `doc` | Folder with .md files |
| `--embedding-model` | `sentence-transformers/all-MiniLM-L6-v2` | Embedding model |
| `--max-tokens` | `512` | Max tokens to generate |
| `--temperature` | `0.7` | Generation temperature |
| `--device` | `auto` | Device for model loading |

## How It Works

### 1. Document Processing

- **.osc files**: Filename parsing extracts keywords (e.g., `highway_lane_change.osc` → `["highway", "lane", "change"]`)
- **.md files**: Content is chunked into overlapping segments for better retrieval
- **Embeddings**: All text is converted to vector representations using Sentence Transformers

### 2. Query Processing

1. **User query** is converted to an embedding
2. **Cosine similarity** finds most relevant scenarios and documentation
3. **Context filtering** determines if documentation lookup is needed
4. **Prompt enhancement** combines user query with retrieved context

### 3. Generation

- **RAG-enhanced prompt** is sent to GPT-OSS model
- **Streaming output** provides real-time responses
- **Context attribution** shows which sources were used

## Example Interactions

### Scenario Request
```
Query: vehicle merging onto highway
Context used:
Relevant scenarios:
- highway_merge_scenario.osc: highway merge scenario (score: 0.891)

Generated Response:
Here's a highway merge scenario based on the context:

[Generated OpenSCENARIO code...]
```

### Documentation Question
```
Query: how to use import statements in OpenSCENARIO
Context used:
Relevant documentation:  
- openscenario_basics.md: Use `import osc.types` and `import osc.helpers`... (score: 0.756)

Generated Response:
In OpenSCENARIO, import statements are used to include standard libraries...
```

## File Naming Conventions

For best results with .osc files, use descriptive filenames:

### Good Examples
- `highway_lane_change_scenario.osc`
- `urban_intersection_crossing.osc`
- `parking_lot_reverse_scenario.osc`
- `emergency_braking_test.osc`

### Avoid
- `scenario1.osc`
- `test.osc`
- `untitled.osc`

## Troubleshooting

### Common Issues

1. **No GPU Memory**: Use GPT-OSS 20B which requires ~16GB
2. **Import Errors**: Ensure all dependencies from gpt-oss-recipes are installed
3. **Empty Results**: Check that .osc and .md files exist in correct folders
4. **Slow First Run**: Initial embedding creation takes time, subsequent runs use cache

### Performance Tips

- **Cache Embeddings**: First run creates embeddings cache for faster subsequent queries
- **GPU Usage**: Ensure CUDA is available for model inference
- **Memory Management**: Close other GPU applications before running

### Debugging

```bash
# Enable verbose logging
export PYTHONPATH=.
python -c "import logging; logging.basicConfig(level=logging.DEBUG)"
python rag_inference.py --query "test query"
```

## Architecture

```
User Query
     ↓
[Document Processor] → [Embedding Manager] → [RAG System]
     ↓                       ↓                      ↓
.osc & .md files      Vector Embeddings     Context Retrieval
     ↓                       ↓                      ↓
[RAG-Enhanced Prompt] → [GPT-OSS Model] → [Generated Response]
```

## Customization

### Adding New Document Types

Modify `document_processor.py` to handle additional file formats:

```python
def process_custom_files(self) -> List[Dict[str, str]]:
    # Add processing for new file types
    pass
```

### Custom Similarity Metrics

Update `embedding_manager.py` to use different similarity measures:

```python
from sklearn.metrics.pairwise import euclidean_distances
# Use euclidean distance instead of cosine similarity
```

### Different Embedding Models

```bash
python rag_inference.py --embedding-model "sentence-transformers/all-mpnet-base-v2"
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes and test thoroughly  
4. Submit a pull request

## License

This project follows the same license as the gpt-oss-recipes repository and OpenAI's GPT-OSS models.

## Support

For issues specific to:
- **RAG system**: Open an issue in this repository
- **GPT-OSS model**: Refer to [gpt-oss-recipes](https://github.com/huggingface/gpt-oss-recipes)
- **OpenSCENARIO**: Check [ASAM OpenSCENARIO documentation](https://www.asam.net/standards/detail/openscenario/)
