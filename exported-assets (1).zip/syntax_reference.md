# OpenSCENARIO Syntax Reference

## File Structure
```
import statements
namespace declaration (optional)
scenario definitions
```

## Data Types
- `speed`: Velocity values (e.g., 30mps, 50kph)
- `distance`: Length values (e.g., 100m, 1km) 
- `time`: Duration values (e.g., 5s, 2min)
- `angle`: Angular values (e.g., 45deg, 1.5rad)

## Operators
- Arithmetic: `+`, `-`, `*`, `/`
- Comparison: `==`, `!=`, `<`, `>`, `<=`, `>=`
- Logical: `and`, `or`, `not`

## Comments
Use `#` for single-line comments:
```
# This is a comment
scenario test: # This is also a comment
    # More comments inside scenario
```

## Variable Assignment
```
var my_speed: speed = 25mps
var target_position: position = (100m, 200m)
```

## Function Calls
```
distance(vehicle1, vehicle2)
time_to_collision(ego_vehicle, obstacle)
```
