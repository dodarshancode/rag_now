# OpenSCENARIO Basics

## Introduction
OpenSCENARIO is a domain-specific language for describing driving test scenarios for autonomous vehicles.

## Import Statements
Every OpenSCENARIO file should start with import statements:
```
import osc.types
import osc.helpers
```

## Scenario Structure
Scenarios are defined using the `scenario` keyword:
```
scenario my_scenario:
    # scenario content here
```

## Execution Modes
- **serial**: Execute actions one after another
- **parallel**: Execute actions simultaneously

## Common Actions
- `drive_straight(speed)`: Drive straight at specified speed
- `change_lane(target_lane)`: Change to target lane
- `emergency_brake()`: Apply emergency braking
- `wait elapsed(time)`: Wait for specified time
- `wait until condition`: Wait until condition is met

## Speed Units
- `mps`: meters per second
- `kph`: kilometers per hour
- `mph`: miles per hour
