# Advanced OpenSCENARIO Features

## Conditional Logic
Use conditions to create dynamic scenarios:
```
wait until distance(ego_vehicle, other_vehicle) < 10m
```

## Parameters
Define reusable parameters:
```
parameter speed_limit: speed = 25mps
```

## Events and Triggers
Set up event-driven behavior:
```
on collision(ego_vehicle, any):
    ego_vehicle: emergency_brake()
```

## Complex Maneuvers
Combine multiple actions for complex behavior:
```
do parallel:
    ego_vehicle: accelerate_to(30mps)
    other_vehicle: change_lane(left)
    wait elapsed(2s)
```

## Vehicle Properties
Access vehicle state:
- `vehicle.speed`: Current speed
- `vehicle.lane`: Current lane
- `vehicle.position`: Current position
- `vehicle.heading`: Current heading direction
