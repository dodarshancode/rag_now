# Create the main RAG + GPT-OSS inference integration script
main_script_code = '''"""
RAG-Enhanced GPT-OSS Inference Script
Integrates RAG system with GPT-OSS 20B model for scenario-aware code generation

Based on the Hugging Face gpt-oss-recipes generate_all.py structure
"""

import os
import sys
import argparse
import torch
import logging
from typing import Optional, List, Dict
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TextStreamer
)

# Import our RAG system
from rag_system import RAGSystem

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class RAGEnhancedInference:
    """
    RAG-enhanced inference system for GPT-OSS models
    """
    
    def __init__(
        self,
        model_path: str = "openai/gpt-oss-20b",
        data_folder: str = "data",
        doc_folder: str = "doc",
        embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2",
        device: str = "auto"
    ):
        self.model_path = model_path
        self.device = device
        
        # Initialize RAG system
        logger.info("Initializing RAG system...")
        self.rag_system = RAGSystem(
            data_folder=data_folder,
            doc_folder=doc_folder,
            model_name=embedding_model
        )
        self.rag_system.initialize_documents()
        
        # Initialize GPT-OSS model and tokenizer
        logger.info(f"Loading GPT-OSS model: {model_path}")
        self.tokenizer = AutoTokenizer.from_pretrained(model_path)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_path,
            torch_dtype="auto",
            device_map=device,
            trust_remote_code=True
        )
        
        # Setup text streamer for real-time output
        self.streamer = TextStreamer(self.tokenizer, skip_prompt=True)
        
        logger.info("RAG-enhanced inference system initialized")
    
    def create_rag_prompt(self, user_query: str, context: Dict) -> str:
        """
        Create a prompt that includes RAG context for the GPT-OSS model
        """
        # Build context string
        context_parts = []
        
        # Add scenario context
        if context["scenarios"]:
            context_parts.append("Relevant OpenSCENARIO examples:")
            for i, scenario in enumerate(context["scenarios"], 1):
                context_parts.append(f"{i}. File: {scenario['filename']}")
                context_parts.append(f"   Description: {scenario['description']}")
                if scenario['keywords']:
                    context_parts.append(f"   Keywords: {', '.join(scenario['keywords'])}")
                context_parts.append(f"   Content preview: {scenario['content_snippet']}")
                context_parts.append("")
        
        # Add documentation context
        if context["documentation"]:
            context_parts.append("Relevant documentation:")
            for i, doc in enumerate(context["documentation"], 1):
                context_parts.append(f"{i}. From {doc['filename']}:")
                context_parts.append(f"   {doc['content']}")
                context_parts.append("")
        
        context_str = "\\n".join(context_parts)
        
        # Create the final prompt
        prompt = f"""You are an expert in OpenSCENARIO 2 DSL for autonomous vehicle scenario generation.

Context from relevant scenarios and documentation:
{context_str}

User request: {user_query}

Please provide a helpful response based on the context above. If generating OpenSCENARIO code, ensure it follows proper syntax and includes necessary imports.

Response:"""
        
        return prompt
    
    def inference(
        self,
        user_query: str,
        max_new_tokens: int = 512,
        temperature: float = 0.7,
        top_p: float = 0.9,
        do_sample: bool = True,
        use_streamer: bool = True,
        scenario_top_k: int = 2,
        doc_top_k: int = 2
    ) -> str:
        """
        Perform RAG-enhanced inference
        """
        logger.info(f"Processing query: '{user_query}'")
        
        # Step 1: Retrieve relevant context using RAG
        logger.info("Retrieving relevant context...")
        context = self.rag_system.get_context_for_query(
            user_query,
            scenario_top_k=scenario_top_k,
            doc_top_k=doc_top_k
        )
        
        # Log retrieved context
        logger.info(f"Retrieved {len(context['scenarios'])} scenarios and {len(context['documentation'])} docs")
        
        # Step 2: Create RAG-enhanced prompt
        rag_prompt = self.create_rag_prompt(user_query, context)
        
        # Step 3: Tokenize and prepare for inference
        messages = [{"role": "user", "content": rag_prompt}]
        
        inputs = self.tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            return_tensors="pt",
            return_dict=True,
        ).to(self.model.device)
        
        # Step 4: Generate response
        logger.info("Generating response...")
        print(f"\\n{'='*60}")
        print(f"Query: {user_query}")
        print(f"{'='*60}")
        print("Context used:")
        print(context["context_summary"])
        print(f"\\n{'-'*60}")
        print("Generated Response:")
        print(f"{'-'*60}")
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                top_p=top_p,
                do_sample=do_sample,
                streamer=self.streamer if use_streamer else None,
                pad_token_id=self.tokenizer.eos_token_id
            )
        
        if not use_streamer:
            # Decode the response if not using streamer
            response_tokens = outputs[0][inputs['input_ids'].shape[-1]:]
            response = self.tokenizer.decode(response_tokens, skip_special_tokens=True)
            print(response)
            return response
        
        return ""  # Response already printed by streamer
    
    def interactive_mode(self):
        """
        Run in interactive mode for continuous queries
        """
        print(f"\\n{'='*80}")
        print("RAG-Enhanced GPT-OSS Interactive Mode")
        print(f"Model: {self.model_path}")
        print(f"Data folder: {self.rag_system.data_folder} ({len(self.rag_system.osc_documents)} .osc files)")
        print(f"Doc folder: {self.rag_system.doc_folder} ({len(self.rag_system.md_documents)} .md chunks)")
        print("Type 'quit', 'exit', or 'q' to exit")
        print("Type 'refresh' to reload documents")
        print("Type 'info' for system information")
        print(f"{'='*80}\\n")
        
        while True:
            try:
                user_input = input("\\nQuery: ").strip()
                
                if not user_input:
                    continue
                
                if user_input.lower() in ['quit', 'exit', 'q']:
                    print("Goodbye!")
                    break
                
                elif user_input.lower() == 'refresh':
                    print("Refreshing documents...")
                    self.rag_system.refresh_documents()
                    print("Documents refreshed!")
                    continue
                
                elif user_input.lower() == 'info':
                    info = self.rag_system.get_system_info()
                    print("\\nSystem Information:")
                    for key, value in info.items():
                        print(f"  {key}: {value}")
                    continue
                
                # Perform inference
                self.inference(user_input)
                
            except KeyboardInterrupt:
                print("\\n\\nInterrupted by user. Goodbye!")
                break
            except Exception as e:
                logger.error(f"Error during inference: {e}")
                print(f"Error: {e}")

def main():
    parser = argparse.ArgumentParser(description="RAG-Enhanced GPT-OSS Inference")
    
    parser.add_argument(
        "--model", 
        type=str, 
        default="openai/gpt-oss-20b",
        help="Model path or name (default: openai/gpt-oss-20b)"
    )
    parser.add_argument(
        "--data-folder",
        type=str,
        default="data", 
        help="Folder containing .osc files (default: data)"
    )
    parser.add_argument(
        "--doc-folder",
        type=str,
        default="doc",
        help="Folder containing .md documentation files (default: doc)"
    )
    parser.add_argument(
        "--embedding-model",
        type=str,
        default="sentence-transformers/all-MiniLM-L6-v2",
        help="Embedding model for RAG (default: sentence-transformers/all-MiniLM-L6-v2)"
    )
    parser.add_argument(
        "--query",
        type=str,
        help="Single query to process (if not provided, enters interactive mode)"
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=512,
        help="Maximum number of tokens to generate (default: 512)"
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.7,
        help="Temperature for generation (default: 0.7)"
    )
    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        help="Device for model loading (default: auto)"
    )
    
    args = parser.parse_args()
    
    # Initialize the RAG-enhanced inference system
    try:
        inference_system = RAGEnhancedInference(
            model_path=args.model,
            data_folder=args.data_folder,
            doc_folder=args.doc_folder,
            embedding_model=args.embedding_model,
            device=args.device
        )
        
        if args.query:
            # Single query mode
            inference_system.inference(
                args.query,
                max_new_tokens=args.max_tokens,
                temperature=args.temperature
            )
        else:
            # Interactive mode
            inference_system.interactive_mode()
            
    except Exception as e:
        logger.error(f"Failed to initialize system: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
'''

with open('rag_inference.py', 'w') as f:
    f.write(main_script_code)

print("✓ Created rag_inference.py - Main RAG + GPT-OSS integration script")
print("This script provides:")
print("- Complete integration with GPT-OSS 20B model")  
print("- RAG context retrieval and prompt enhancement")
print("- Interactive mode for continuous queries")
print("- Single query mode for batch processing")
print("- Configurable parameters for generation and retrieval")
print("- Real-time streaming output")
print("- Document refresh capability")