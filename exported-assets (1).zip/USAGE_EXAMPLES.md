# RAG-Enhanced GPT-OSS Usage Examples

## Quick Start

### 1. Basic Setup
```bash
# Install additional dependencies
pip install sentence-transformers scikit-learn nltk

# Run setup to create example files
python setup.py

# Start interactive mode
python rag_inference.py
```

### 2. Example Queries

#### Scenario Generation
```
Query: "Create a highway merging scenario where a vehicle merges from on-ramp"
```

#### Documentation Questions
```
Query: "How do I use import statements in OpenSCENARIO?"
Query: "What are the different execution modes?"
Query: "Explain the syntax for conditional logic"
```

#### Specific Features  
```
Query: "Show me how to implement emergency braking"
Query: "Create a parallel parking scenario"  
Query: "How to define vehicle parameters"
```

## Command Line Examples

### Single Query Mode
```bash
# Basic query
python rag_inference.py --query "vehicle changing lanes on highway"

# With custom parameters
python rag_inference.py \
  --query "intersection crossing scenario" \
  --max-tokens 1024 \
  --temperature 0.8

# Using different model (if available)
python rag_inference.py \
  --model "openai/gpt-oss-120b" \
  --query "complex urban scenario"
```

### Custom Directories
```bash
python rag_inference.py \
  --data-folder "my_scenarios" \
  --doc-folder "my_documentation" \
  --query "custom scenario request"
```

## Interactive Mode Commands

```
# Special commands in interactive mode:
Query: refresh          # Reload all documents
Query: info            # Show system information  
Query: quit            # Exit the program
```

## File Organization Examples

### Good .osc File Names
```
data/highway_lane_change_scenario.osc
data/urban_intersection_crossing.osc  
data/emergency_braking_test.osc
data/parking_lot_reverse_maneuver.osc
data/freeway_merge_complex.osc
```

### Good .md Documentation Structure
```
doc/openscenario_basics.md
doc/syntax_reference.md
doc/advanced_features.md
doc/vehicle_actions_guide.md
doc/conditional_logic_examples.md
```

## Expected System Behavior

### When you ask: "Create a lane change scenario"
```
Context used:
Relevant scenarios:
- highway_lane_change_scenario.osc: highway lane change scenario (score: 0.891)

Generated Response:
Based on the highway lane change scenario context, here's an OpenSCENARIO implementation:

[Generated code with proper imports and scenario structure]
```

### When you ask: "How to use import statements"
```  
Context used:
Relevant documentation:
- openscenario_basics.md: Use `import osc.types` and `import osc.helpers`... (score: 0.756)

Generated Response:
In OpenSCENARIO, import statements are essential for including standard libraries...
```

## Performance Tips

1. **First Run**: Initial embedding creation takes time, but subsequent runs are fast
2. **File Naming**: Use descriptive names for better scenario matching
3. **Documentation**: Keep .md files focused and well-structured
4. **Caching**: Embeddings are cached automatically - delete `embeddings/` to rebuild
5. **Memory**: Ensure sufficient GPU memory for GPT-OSS model (16GB+ recommended)

## Troubleshooting Common Issues

### No Relevant Context Found
- Check that .osc and .md files exist in correct folders
- Verify file names are descriptive
- Try broader query terms

### Low Similarity Scores
- Improve file naming conventions
- Add more relevant documentation
- Use synonyms in queries

### Model Loading Issues  
- Verify gpt-oss-recipes environment is active
- Check GPU memory availability
- Try smaller model (gpt-oss-20b vs gpt-oss-120b)

### Import Errors
- Ensure all dependencies are installed
- Verify Python path includes current directory
- Check that all .py files are in same directory
