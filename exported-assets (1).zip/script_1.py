# Create requirements.txt with necessary dependencies
requirements = """# Core dependencies for RAG system
sentence-transformers==2.2.2
scikit-learn>=1.3.0
numpy>=1.24.0
pandas>=2.0.0

# Text processing
nltk>=3.8
regex>=2023.0.0

# File handling
pathlib
glob2

# For potential future enhancements
faiss-cpu>=1.7.4  # Optional: for larger scale vector search
chromadb>=0.4.0   # Optional: alternative vector database

# Note: torch, transformers, and other ML dependencies 
# should already be installed from gpt-oss-recipes repository
"""

with open('requirements.txt', 'w') as f:
    f.write(requirements)

print("✓ Created requirements.txt")
print("Contents:")
print(requirements)