# Let's test our document processor to make sure it works
print("Testing the document processor implementation...")

# First, let me run the setup to create example files
exec(open('setup.py').read())

print("\n" + "="*50)
print("Now testing the document processor...")

# Import and test our document processor
try:
    from document_processor import DocumentProcessor
    
    # Initialize processor
    processor = DocumentProcessor()
    
    # Test processing
    osc_docs, md_docs = processor.get_all_documents()
    
    print(f"\n✓ Successfully processed {len(osc_docs)} OSC files and {len(md_docs)} MD chunks")
    
    # Show example results
    if osc_docs:
        print(f"\nExample OSC document:")
        print(f"Filename: {osc_docs[0]['filename']}")
        print(f"Keywords: {osc_docs[0].get('keywords', [])}")
        print(f"Description: {osc_docs[0].get('description', '')}")
        print(f"Content preview: {osc_docs[0].get('content', '')[:100]}...")
    
    if md_docs:
        print(f"\nExample MD chunk:")
        print(f"Filename: {md_docs[0]['filename']}")
        print(f"Content preview: {md_docs[0]['content'][:150]}...")
        
    print("\n✓ Document processor working correctly!")
    
except Exception as e:
    print(f"✗ Error testing document processor: {e}")
    import traceback
    traceback.print_exc()