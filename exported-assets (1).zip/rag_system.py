"""
RAG System for OpenSCENARIO and Documentation Retrieval
Combines document processing and embedding-based search for GPT-OSS inference
"""

import os
import json
import logging
from typing import List, Dict, Tuple, Optional
from pathlib import Path

from document_processor import DocumentProcessor
from embedding_manager import EmbeddingManager

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RAGSystem:
    """
    Main RAG system that combines document processing and similarity search
    Provides context retrieval for GPT-OSS model inference
    """

    def __init__(
        self,
        data_folder: str = "data",
        doc_folder: str = "doc", 
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        cache_dir: str = "embeddings"
    ):
        self.data_folder = data_folder
        self.doc_folder = doc_folder

        # Initialize components
        logger.info("Initializing RAG system components...")
        self.document_processor = DocumentProcessor(data_folder, doc_folder)
        self.embedding_manager = EmbeddingManager(model_name, cache_dir)

        # Document storage
        self.osc_documents = []
        self.md_documents = []
        self.is_initialized = False

        logger.info("RAG system initialized")

    def initialize_documents(self, force_rebuild: bool = False):
        """
        Process documents and create embeddings
        """
        logger.info("Processing documents...")

        # Process documents
        self.osc_documents, self.md_documents = self.document_processor.get_all_documents()

        # Create embeddings
        if self.osc_documents:
            self.embedding_manager.prepare_osc_embeddings(self.osc_documents, force_rebuild)
        else:
            logger.warning("No .osc files found in data folder")

        if self.md_documents:
            self.embedding_manager.prepare_md_embeddings(self.md_documents, force_rebuild)
        else:
            logger.warning("No .md files found in doc folder")

        self.is_initialized = True
        logger.info("Document initialization complete")

    def search_scenarios(self, query: str, top_k: int = 3) -> List[Dict]:
        """
        Search for similar scenarios based on query
        Returns relevant .osc files with metadata
        """
        if not self.is_initialized:
            self.initialize_documents()

        results = self.embedding_manager.search_similar_scenarios(query, top_k)

        # Format results for easy consumption
        formatted_results = []
        for doc, score in results:
            result = {
                "type": "scenario",
                "filename": doc.get("filename", "unknown"),
                "description": doc.get("description", ""),
                "keywords": doc.get("keywords", []),
                "content_snippet": doc.get("content", "")[:300],
                "similarity_score": score,
                "metadata": {
                    "scenarios_found": doc.get("scenarios_found", []),
                    "imports": doc.get("imports", []),
                    "file_size": doc.get("file_size", 0)
                }
            }
            formatted_results.append(result)

        return formatted_results

    def search_documentation(self, query: str, top_k: int = 3, min_score: float = 0.3) -> List[Dict]:
        """
        Search for relevant documentation based on query
        Returns relevant .md file chunks
        """
        if not self.is_initialized:
            self.initialize_documents()

        results = self.embedding_manager.search_documentation(query, top_k, min_score)

        # Format results for easy consumption
        formatted_results = []
        for doc, score in results:
            result = {
                "type": "documentation", 
                "filename": doc.get("filename", "unknown"),
                "content": doc.get("content", ""),
                "similarity_score": score,
                "metadata": {
                    "chunk_id": doc.get("chunk_id"),
                    "source_file": doc.get("source_file")
                }
            }
            formatted_results.append(result)

        return formatted_results

    def get_context_for_query(
        self, 
        query: str, 
        scenario_top_k: int = 2,
        doc_top_k: int = 2,
        doc_min_score: float = 0.3,
        include_documentation: bool = True
    ) -> Dict[str, any]:
        """
        Get comprehensive context for a user query
        Combines scenario search and documentation search
        """
        logger.info(f"Retrieving context for query: '{query}'")

        # Search scenarios
        scenario_results = self.search_scenarios(query, scenario_top_k)

        # Search documentation if needed
        doc_results = []
        if include_documentation:
            # Determine if query needs documentation lookup
            needs_doc = self._needs_documentation_lookup(query, scenario_results)
            if needs_doc:
                doc_results = self.search_documentation(query, doc_top_k, doc_min_score)

        context = {
            "query": query,
            "scenarios": scenario_results,
            "documentation": doc_results,
            "context_summary": self._create_context_summary(scenario_results, doc_results)
        }

        logger.info(f"Retrieved {len(scenario_results)} scenarios and {len(doc_results)} docs")
        return context

    def _needs_documentation_lookup(self, query: str, scenario_results: List[Dict]) -> bool:
        """
        Determine if the query needs additional documentation lookup
        """
        # Simple heuristics to determine if we need documentation

        # If no good scenario matches
        if not scenario_results or all(r["similarity_score"] < 0.5 for r in scenario_results):
            return True

        # If query contains documentation-seeking keywords
        doc_keywords = [
            "how to", "what is", "explain", "documentation", "guide", 
            "syntax", "format", "example", "tutorial", "reference"
        ]

        query_lower = query.lower()
        if any(keyword in query_lower for keyword in doc_keywords):
            return True

        return False

    def _create_context_summary(self, scenarios: List[Dict], docs: List[Dict]) -> str:
        """
        Create a summary of the retrieved context for the LLM
        """
        summary_parts = []

        if scenarios:
            scenario_info = []
            for s in scenarios:
                info = f"- {s['filename']}: {s['description']} (score: {s['similarity_score']:.3f})"
                scenario_info.append(info)
            summary_parts.append(f"Relevant scenarios:\n" + "\n".join(scenario_info))

        if docs:
            doc_info = []
            for d in docs:
                content_preview = d['content'][:100] + "..." if len(d['content']) > 100 else d['content']
                info = f"- {d['filename']}: {content_preview} (score: {d['similarity_score']:.3f})"
                doc_info.append(info)
            summary_parts.append(f"Relevant documentation:\n" + "\n".join(doc_info))

        return "\n\n".join(summary_parts) if summary_parts else "No relevant context found."

    def get_system_info(self) -> Dict[str, any]:
        """
        Get information about the RAG system state
        """
        info = {
            "initialized": self.is_initialized,
            "data_folder": self.data_folder,
            "doc_folder": self.doc_folder,
            "osc_documents_count": len(self.osc_documents),
            "md_documents_count": len(self.md_documents)
        }

        if self.is_initialized:
            info["embedding_info"] = self.embedding_manager.get_embeddings_info()

        return info

    def refresh_documents(self):
        """
        Refresh documents and rebuild embeddings
        Useful when files have been added or modified
        """
        logger.info("Refreshing documents and rebuilding embeddings...")
        self.initialize_documents(force_rebuild=True)
        logger.info("Document refresh complete")

if __name__ == "__main__":
    # Example usage and testing
    print("Testing RAG System...")

    # Create example directories and files
    os.makedirs("data", exist_ok=True)
    os.makedirs("doc", exist_ok=True)

    # Example .osc files
    osc_examples = {
        "highway_merge_scenario.osc": """import osc.types
import osc.helpers

scenario highway_merge:
    # Vehicle merging onto highway
    do parallel:
        ego_vehicle: accelerate_to(speed: 25mps)
        other_vehicle: maintain_speed(speed: 30mps)
""",
        "city_intersection_scenario.osc": """import osc.types
import osc.helpers

scenario city_intersection:  
    # Urban intersection crossing
    do serial:
        ego_vehicle: approach_intersection()
        traffic_light: change_to(green)
        ego_vehicle: cross_intersection()
"""
    }

    for filename, content in osc_examples.items():
        with open(f"data/{filename}", "w") as f:
            f.write(content)

    # Example .md documentation
    md_examples = {
        "openscenario_basics.md": """# OpenSCENARIO Basics

## Import Statements
Use `import osc.types` and `import osc.helpers` to include standard libraries.

## Scenario Structure
Scenarios are defined with the `scenario` keyword followed by a name and colon.

## Execution Modes
- `serial`: Execute actions one after another
- `parallel`: Execute actions simultaneously

## Common Actions
- `accelerate_to(speed)`: Set vehicle speed
- `maintain_speed(speed)`: Keep constant speed
- `approach_intersection()`: Navigate to intersection
""",
        "advanced_features.md": """# Advanced OpenSCENARIO Features

## Conditional Logic
Use conditions to trigger different behaviors based on scenario state.

## Parameter Usage
Define reusable parameters for scenario customization.

## Event Handling
Set up event-driven scenario execution with triggers and conditions.
"""
    }

    for filename, content in md_examples.items():
        with open(f"doc/{filename}", "w") as f:
            f.write(content)

    print("Created example files")

    # Initialize RAG system
    rag = RAGSystem()

    # Test queries
    test_queries = [
        "vehicle merging onto highway",
        "how to use import statements in scenarios",
        "intersection crossing scenario",
        "what are execution modes in OpenSCENARIO"
    ]

    print("\n=== Testing RAG System ===")
    for query in test_queries:
        print(f"\nQuery: '{query}'")
        context = rag.get_context_for_query(query)

        print(f"Found {len(context['scenarios'])} scenarios and {len(context['documentation'])} docs")

        if context['scenarios']:
            best_scenario = context['scenarios'][0]
            print(f"Best scenario: {best_scenario['filename']} (score: {best_scenario['similarity_score']:.3f})")

        if context['documentation']:
            best_doc = context['documentation'][0]
            print(f"Best doc: {best_doc['filename']} (score: {best_doc['similarity_score']:.3f})")

    print(f"\nSystem info: {rag.get_system_info()}")
    print("\n✓ RAG System module ready")
