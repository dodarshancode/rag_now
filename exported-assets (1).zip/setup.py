#!/usr/bin/env python3
"""
Setup script for RAG-Enhanced GPT-OSS System
Creates example files and verifies the installation
"""

import os
import sys
from pathlib import Path

def create_example_files():
    """Create example .osc and .md files for testing"""

    # Create directories
    Path("data").mkdir(exist_ok=True)
    Path("doc").mkdir(exist_ok=True)
    Path("embeddings").mkdir(exist_ok=True)

    # Example .osc files
    osc_examples = {
        "highway_lane_change_scenario.osc": """import osc.types
import osc.helpers

scenario highway_lane_change:
    # Vehicle changing lanes on highway
    do parallel:
        ego_vehicle: drive_in_lane(lane: 1, speed: 30mps)
        other_vehicle: drive_in_lane(lane: 2, speed: 25mps)
        wait elapsed(5s)
        ego_vehicle: change_lane(target_lane: 2)
        wait until ego_vehicle.lane == 2
""",

        "city_intersection_crossing.osc": """import osc.types
import osc.helpers

scenario city_intersection_crossing:
    # Urban intersection navigation
    do serial:
        ego_vehicle: approach(intersection_01, speed: 15mps)
        wait until distance(ego_vehicle, intersection_01) < 50m
        traffic_light: change_to(green)
        ego_vehicle: cross_intersection(intersection_01)
        wait until ego_vehicle.passed(intersection_01)
""",

        "emergency_braking_test.osc": """import osc.types
import osc.helpers

scenario emergency_braking:
    # Emergency braking scenario
    do parallel:
        ego_vehicle: drive_straight(speed: 20mps)
        obstacle_vehicle: drive_straight(speed: 5mps)
        wait elapsed(3s)
        obstacle_vehicle: emergency_brake()
        ego_vehicle: emergency_brake()
""",

        "parking_lot_navigation.osc": """import osc.types
import osc.helpers

scenario parking_lot_navigation:
    # Vehicle parking scenario
    do serial:
        ego_vehicle: enter_parking_lot()
        ego_vehicle: find_parking_space()
        ego_vehicle: park(space: parking_space_01)
        wait until ego_vehicle.parked
"""
    }

    for filename, content in osc_examples.items():
        with open(f"data/{filename}", "w") as f:
            f.write(content)

    print(f"✓ Created {len(osc_examples)} example .osc files in data/")

    # Example .md documentation files
    md_examples = {
        "openscenario_basics.md": """# OpenSCENARIO Basics

## Introduction
OpenSCENARIO is a domain-specific language for describing driving test scenarios for autonomous vehicles.

## Import Statements
Every OpenSCENARIO file should start with import statements:
```
import osc.types
import osc.helpers
```

## Scenario Structure
Scenarios are defined using the `scenario` keyword:
```
scenario my_scenario:
    # scenario content here
```

## Execution Modes
- **serial**: Execute actions one after another
- **parallel**: Execute actions simultaneously

## Common Actions
- `drive_straight(speed)`: Drive straight at specified speed
- `change_lane(target_lane)`: Change to target lane
- `emergency_brake()`: Apply emergency braking
- `wait elapsed(time)`: Wait for specified time
- `wait until condition`: Wait until condition is met

## Speed Units
- `mps`: meters per second
- `kph`: kilometers per hour
- `mph`: miles per hour
""",

        "advanced_features.md": """# Advanced OpenSCENARIO Features

## Conditional Logic
Use conditions to create dynamic scenarios:
```
wait until distance(ego_vehicle, other_vehicle) < 10m
```

## Parameters
Define reusable parameters:
```
parameter speed_limit: speed = 25mps
```

## Events and Triggers
Set up event-driven behavior:
```
on collision(ego_vehicle, any):
    ego_vehicle: emergency_brake()
```

## Complex Maneuvers
Combine multiple actions for complex behavior:
```
do parallel:
    ego_vehicle: accelerate_to(30mps)
    other_vehicle: change_lane(left)
    wait elapsed(2s)
```

## Vehicle Properties
Access vehicle state:
- `vehicle.speed`: Current speed
- `vehicle.lane`: Current lane
- `vehicle.position`: Current position
- `vehicle.heading`: Current heading direction
""",

        "syntax_reference.md": """# OpenSCENARIO Syntax Reference

## File Structure
```
import statements
namespace declaration (optional)
scenario definitions
```

## Data Types
- `speed`: Velocity values (e.g., 30mps, 50kph)
- `distance`: Length values (e.g., 100m, 1km) 
- `time`: Duration values (e.g., 5s, 2min)
- `angle`: Angular values (e.g., 45deg, 1.5rad)

## Operators
- Arithmetic: `+`, `-`, `*`, `/`
- Comparison: `==`, `!=`, `<`, `>`, `<=`, `>=`
- Logical: `and`, `or`, `not`

## Comments
Use `#` for single-line comments:
```
# This is a comment
scenario test: # This is also a comment
    # More comments inside scenario
```

## Variable Assignment
```
var my_speed: speed = 25mps
var target_position: position = (100m, 200m)
```

## Function Calls
```
distance(vehicle1, vehicle2)
time_to_collision(ego_vehicle, obstacle)
```
"""
    }

    for filename, content in md_examples.items():
        with open(f"doc/{filename}", "w") as f:
            f.write(content)

    print(f"✓ Created {len(md_examples)} example .md files in doc/")

def check_dependencies():
    """Check if required dependencies are available"""

    required_packages = [
        "torch",
        "transformers", 
        "sentence_transformers",
        "sklearn",
        "numpy"
    ]

    missing_packages = []

    for package in required_packages:
        try:
            __import__(package.replace("-", "_"))
            print(f"✓ {package} is available")
        except ImportError:
            missing_packages.append(package)
            print(f"✗ {package} is missing")

    if missing_packages:
        print(f"\nMissing packages: {', '.join(missing_packages)}")
        print("Please install them using:")
        print(f"pip install {' '.join(missing_packages)}")
        return False

    return True

def test_rag_system():
    """Test the RAG system with example files"""

    try:
        print("\n=== Testing RAG System ===")

        # Test imports
        from document_processor import DocumentProcessor
        from embedding_manager import EmbeddingManager  
        from rag_system import RAGSystem
        print("✓ All modules import successfully")

        # Test document processing
        processor = DocumentProcessor()
        osc_docs, md_docs = processor.get_all_documents()
        print(f"✓ Processed {len(osc_docs)} .osc files and {len(md_docs)} .md chunks")

        # Test RAG system (without model loading)
        print("✓ RAG system components working")

        return True

    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ Error testing RAG system: {e}")
        return False

def main():
    """Main setup function"""

    print("RAG-Enhanced GPT-OSS Setup")
    print("=" * 40)

    # Create example files
    print("\n1. Creating example files...")
    create_example_files()

    # Check dependencies
    print("\n2. Checking dependencies...")
    deps_ok = check_dependencies()

    # Test RAG system
    print("\n3. Testing RAG system...")
    rag_ok = test_rag_system()

    # Summary
    print("\n" + "=" * 40)
    if deps_ok and rag_ok:
        print("✓ Setup completed successfully!")
        print("\nYou can now run:")
        print("  python rag_inference.py")
        print("\nOr for a test query:")
        print("  python rag_inference.py --query 'create a lane change scenario'")
    else:
        print("✗ Setup completed with issues.")
        print("Please resolve the issues above before running the system.")

    print("\nFor more information, see README.md")

if __name__ == "__main__":
    main()
