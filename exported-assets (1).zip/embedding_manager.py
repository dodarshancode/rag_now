"""
Embedding Manager for RAG System
Handles text embeddings and similarity search using Sentence Transformers
"""

import os
import json
import pickle
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Union
import logging
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EmbeddingManager:
    """
    Manages embeddings for the RAG system:
    - Creates embeddings using Sentence Transformers
    - Stores and loads embeddings from cache
    - Performs similarity search
    """

    def __init__(
        self, 
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        cache_dir: str = "embeddings",
        device: str = "cpu"
    ):
        self.model_name = model_name
        self.cache_dir = Path(cache_dir)
        self.device = device

        # Create cache directory
        self.cache_dir.mkdir(exist_ok=True)

        # Initialize the embedding model
        logger.info(f"Loading embedding model: {model_name}")
        self.model = SentenceTransformer(model_name, device=device)
        logger.info(f"Model loaded on device: {self.model.device}")

        # Storage for embeddings and documents
        self.osc_embeddings = None
        self.md_embeddings = None
        self.osc_documents = []
        self.md_documents = []

    def create_embeddings(self, texts: List[str], batch_size: int = 32) -> np.ndarray:
        """
        Create embeddings for a list of texts
        """
        logger.info(f"Creating embeddings for {len(texts)} texts")
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=True,
            convert_to_numpy=True,
            normalize_embeddings=True
        )
        return embeddings

    def save_embeddings(self, embeddings: np.ndarray, documents: List[Dict], filename: str):
        """
        Save embeddings and documents to cache
        """
        cache_path = self.cache_dir / f"{filename}.pkl"

        data = {
            "embeddings": embeddings,
            "documents": documents,
            "model_name": self.model_name,
            "embedding_dim": embeddings.shape[1] if embeddings.size > 0 else 0
        }

        with open(cache_path, 'wb') as f:
            pickle.dump(data, f)

        logger.info(f"Saved embeddings to {cache_path}")

    def load_embeddings(self, filename: str) -> Tuple[Optional[np.ndarray], List[Dict]]:
        """
        Load embeddings and documents from cache
        """
        cache_path = self.cache_dir / f"{filename}.pkl"

        if not cache_path.exists():
            logger.info(f"Cache file {cache_path} not found")
            return None, []

        try:
            with open(cache_path, 'rb') as f:
                data = pickle.load(f)

            # Check if the model matches
            if data.get("model_name") != self.model_name:
                logger.warning(f"Model mismatch in cache. Expected: {self.model_name}, Found: {data.get('model_name')}")
                return None, []

            logger.info(f"Loaded embeddings from {cache_path}")
            return data["embeddings"], data["documents"]

        except Exception as e:
            logger.error(f"Error loading embeddings from {cache_path}: {e}")
            return None, []

    def prepare_osc_embeddings(self, osc_documents: List[Dict], force_rebuild: bool = False):
        """
        Prepare embeddings for .osc files (based on filenames and metadata)
        """
        if not force_rebuild:
            embeddings, docs = self.load_embeddings("osc_embeddings")
            if embeddings is not None and len(docs) == len(osc_documents):
                self.osc_embeddings = embeddings
                self.osc_documents = docs
                logger.info("Loaded OSC embeddings from cache")
                return

        # Create text representations for embedding
        texts = []
        for doc in osc_documents:
            if "error" in doc:
                text = f"Error in file: {doc['filename']}"
            else:
                # Combine filename info and content snippet
                description = doc.get("description", "")
                keywords = " ".join(doc.get("keywords", []))
                content_snippet = doc.get("content", "")[:200]  # First 200 chars

                text = f"Scenario: {description} Keywords: {keywords} Content: {content_snippet}"

            texts.append(text)

        # Create embeddings
        self.osc_embeddings = self.create_embeddings(texts)
        self.osc_documents = osc_documents

        # Save to cache
        self.save_embeddings(self.osc_embeddings, osc_documents, "osc_embeddings")
        logger.info(f"Created and cached embeddings for {len(osc_documents)} OSC documents")

    def prepare_md_embeddings(self, md_documents: List[Dict], force_rebuild: bool = False):
        """
        Prepare embeddings for .md file chunks
        """
        if not force_rebuild:
            embeddings, docs = self.load_embeddings("md_embeddings")
            if embeddings is not None and len(docs) == len(md_documents):
                self.md_embeddings = embeddings
                self.md_documents = docs
                logger.info("Loaded MD embeddings from cache")
                return

        # Create text representations for embedding
        texts = []
        for doc in md_documents:
            if "error" in doc:
                text = f"Error in file: {doc['filename']}"
            else:
                text = doc["content"]

            texts.append(text)

        # Create embeddings
        self.md_embeddings = self.create_embeddings(texts)
        self.md_documents = md_documents

        # Save to cache
        self.save_embeddings(self.md_embeddings, md_documents, "md_embeddings")
        logger.info(f"Created and cached embeddings for {len(md_documents)} MD document chunks")

    def search_similar_scenarios(self, query: str, top_k: int = 3) -> List[Tuple[Dict, float]]:
        """
        Search for similar scenarios in .osc files based on query
        """
        if self.osc_embeddings is None or len(self.osc_documents) == 0:
            logger.warning("No OSC embeddings available")
            return []

        # Create query embedding
        query_embedding = self.create_embeddings([query])

        # Calculate similarities
        similarities = cosine_similarity(query_embedding, self.osc_embeddings)[0]

        # Get top-k results
        top_indices = np.argsort(similarities)[::-1][:top_k]

        results = []
        for idx in top_indices:
            doc = self.osc_documents[idx]
            score = float(similarities[idx])
            results.append((doc, score))

        logger.info(f"Found {len(results)} similar scenarios for query: '{query}'")
        return results

    def search_documentation(self, query: str, top_k: int = 3, min_score: float = 0.3) -> List[Tuple[Dict, float]]:
        """
        Search for relevant documentation chunks based on query
        """
        if self.md_embeddings is None or len(self.md_documents) == 0:
            logger.warning("No MD embeddings available")
            return []

        # Create query embedding
        query_embedding = self.create_embeddings([query])

        # Calculate similarities
        similarities = cosine_similarity(query_embedding, self.md_embeddings)[0]

        # Get top-k results above minimum score
        top_indices = np.argsort(similarities)[::-1][:top_k]

        results = []
        for idx in top_indices:
            score = float(similarities[idx])
            if score >= min_score:
                doc = self.md_documents[idx]
                results.append((doc, score))

        logger.info(f"Found {len(results)} relevant documentation chunks for query: '{query}'")
        return results

    def get_embeddings_info(self) -> Dict[str, Union[int, str]]:
        """
        Get information about loaded embeddings
        """
        info = {
            "model_name": self.model_name,
            "osc_documents": len(self.osc_documents),
            "md_documents": len(self.md_documents),
            "embedding_dimension": self.model.get_sentence_embedding_dimension()
        }

        if self.osc_embeddings is not None:
            info["osc_embedding_shape"] = self.osc_embeddings.shape

        if self.md_embeddings is not None:
            info["md_embedding_shape"] = self.md_embeddings.shape

        return info

if __name__ == "__main__":
    # Example usage and testing
    print("Testing EmbeddingManager...")

    # Initialize manager
    manager = EmbeddingManager()

    # Test with sample documents
    sample_osc_docs = [
        {
            "filename": "highway_lane_change.osc",
            "description": "highway lane change scenario",
            "keywords": ["highway", "lane", "change"],
            "content": "scenario highway_lane_change: do parallel: ego_vehicle drive straight",
            "type": "osc_file"
        }
    ]

    sample_md_docs = [
        {
            "filename": "guide.md", 
            "content": "OpenSCENARIO is a language for describing test scenarios. Use import statements to include libraries.",
            "type": "md_chunk"
        }
    ]

    # Prepare embeddings
    manager.prepare_osc_embeddings(sample_osc_docs)
    manager.prepare_md_embeddings(sample_md_docs)

    # Test search
    scenario_results = manager.search_similar_scenarios("vehicle changing lanes on highway")
    doc_results = manager.search_documentation("how to import libraries")

    print(f"\nScenario search results: {len(scenario_results)}")
    for doc, score in scenario_results:
        print(f"  - {doc['filename']}: {score:.3f}")

    print(f"\nDocumentation search results: {len(doc_results)}")
    for doc, score in doc_results:
        print(f"  - {doc['filename']}: {score:.3f}")

    print(f"\nEmbedding info: {manager.get_embeddings_info()}")
    print("✓ EmbeddingManager module ready")
