"""
Configuration file for RAG-Enhanced GPT-OSS System
Modify these settings to customize the behavior
"""

# Model Configuration
MODEL_CONFIG = {
    "gpt_oss_model": "openai/gpt-oss-20b",  # or "openai/gpt-oss-120b"
    "embedding_model": "sentence-transformers/all-MiniLM-L6-v2",
    "device": "auto",  # "auto", "cuda", "cpu"
}

# Directory Configuration
DIRECTORY_CONFIG = {
    "data_folder": "data",          # .osc scenario files
    "doc_folder": "doc",            # .md documentation files  
    "embeddings_cache": "embeddings",  # cached embeddings
}

# RAG Configuration
RAG_CONFIG = {
    "scenario_top_k": 3,            # top scenarios to retrieve
    "doc_top_k": 3,                 # top documentation chunks to retrieve
    "doc_min_score": 0.3,           # minimum similarity score for docs
    "chunk_size": 500,              # words per documentation chunk
    "chunk_overlap": 50,            # overlap between chunks
}

# Generation Configuration  
GENERATION_CONFIG = {
    "max_new_tokens": 512,          # maximum tokens to generate
    "temperature": 0.7,             # generation temperature (0.0-2.0)
    "top_p": 0.9,                   # nucleus sampling parameter
    "do_sample": True,              # whether to use sampling
    "use_streamer": True,           # real-time output streaming
}

# Embedding Configuration
EMBEDDING_CONFIG = {
    "batch_size": 32,               # batch size for embedding creation
    "normalize_embeddings": True,   # normalize embeddings to unit length
    "cache_embeddings": True,       # cache embeddings for faster loading
}

# Logging Configuration
LOGGING_CONFIG = {
    "level": "INFO",                # DEBUG, INFO, WARNING, ERROR
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
}

# Advanced Configuration
ADVANCED_CONFIG = {
    "auto_refresh_documents": False,    # auto-refresh when files change
    "similarity_metric": "cosine",      # "cosine", "euclidean", "dot_product"
    "query_preprocessing": True,        # preprocess queries (lowercase, etc.)
    "filename_weight": 0.7,             # weight for filename-based similarity
    "content_weight": 0.3,              # weight for content-based similarity
}

# Export all configurations
ALL_CONFIGS = {
    "model": MODEL_CONFIG,
    "directories": DIRECTORY_CONFIG,
    "rag": RAG_CONFIG,
    "generation": GENERATION_CONFIG,
    "embedding": EMBEDDING_CONFIG,
    "logging": LOGGING_CONFIG,
    "advanced": ADVANCED_CONFIG,
}

if __name__ == "__main__":
    import json
    print("Current Configuration:")
    print(json.dumps(ALL_CONFIGS, indent=2))
