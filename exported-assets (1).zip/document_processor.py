"""
Document Processor for RAG System
Handles .osc (OpenSCENARIO) files and .md (Markdown) documentation files
"""

import os
import re
import glob
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DocumentProcessor:
    """
    Processes documents for RAG system:
    - .osc files: extracts metadata from filenames and basic content
    - .md files: processes markdown content with chunking
    """

    def __init__(self, data_folder: str = "data", doc_folder: str = "doc"):
        self.data_folder = Path(data_folder)
        self.doc_folder = Path(doc_folder)

        # Create folders if they don't exist
        self.data_folder.mkdir(exist_ok=True)
        self.doc_folder.mkdir(exist_ok=True)

        logger.info(f"Initialized DocumentProcessor with data_folder={data_folder}, doc_folder={doc_folder}")

    def extract_filename_info(self, filename: str) -> Dict[str, str]:
        """
        Extract semantic information from .osc filenames
        Assumes filenames contain scenario information separated by underscores or dashes
        """
        # Remove file extension
        base_name = Path(filename).stem

        # Split on common separators and clean
        parts = re.split(r'[_\-\s]+', base_name.lower())
        parts = [part.strip() for part in parts if part.strip()]

        # Extract potential scenario metadata
        info = {
            "filename": filename,
            "scenario_name": base_name,
            "keywords": parts,
            "description": " ".join(parts).replace("_", " ").replace("-", " ")
        }

        return info

    def read_osc_file(self, filepath: Path) -> Dict[str, str]:
        """
        Read .osc file and extract basic content information
        """
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()

            # Extract filename info
            file_info = self.extract_filename_info(filepath.name)

            # Basic OSC content extraction (scenario names, imports, etc.)
            scenario_matches = re.findall(r'scenario\s+(\w+):', content)
            import_matches = re.findall(r'import\s+([\w\.]+)', content)

            file_info.update({
                "content": content[:1000],  # First 1000 chars for context
                "full_content": content,
                "scenarios_found": scenario_matches,
                "imports": import_matches,
                "file_size": len(content),
                "type": "osc_file"
            })

            return file_info

        except Exception as e:
            logger.error(f"Error reading .osc file {filepath}: {e}")
            return {"filename": filepath.name, "error": str(e), "type": "osc_file"}

    def read_md_file(self, filepath: Path) -> Dict[str, str]:
        """
        Read .md file and extract content with basic chunking
        """
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()

            # Basic markdown processing
            # Remove markdown formatting for cleaner text
            clean_content = re.sub(r'#{1,6}\s*', '', content)  # Remove headers
            clean_content = re.sub(r'\*\*(.+?)\*\*', r'\1', clean_content)  # Remove bold
            clean_content = re.sub(r'\*(.+?)\*', r'\1', clean_content)  # Remove italic
            clean_content = re.sub(r'`(.+?)`', r'\1', clean_content)  # Remove code
            clean_content = re.sub(r'\[(.+?)\]\(.+?\)', r'\1', clean_content)  # Remove links

            return {
                "filename": filepath.name,
                "content": clean_content,
                "full_content": content,
                "file_size": len(content),
                "type": "md_file"
            }

        except Exception as e:
            logger.error(f"Error reading .md file {filepath}: {e}")
            return {"filename": filepath.name, "error": str(e), "type": "md_file"}

    def chunk_text(self, text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
        """
        Split text into overlapping chunks for better retrieval
        """
        words = text.split()
        chunks = []

        for i in range(0, len(words), chunk_size - overlap):
            chunk = " ".join(words[i:i + chunk_size])
            if chunk.strip():
                chunks.append(chunk.strip())

        return chunks

    def process_osc_files(self) -> List[Dict[str, str]]:
        """
        Process all .osc files in the data folder
        """
        osc_files = list(self.data_folder.glob("*.osc"))
        logger.info(f"Found {len(osc_files)} .osc files")

        processed_files = []
        for filepath in osc_files:
            file_data = self.read_osc_file(filepath)
            processed_files.append(file_data)

        return processed_files

    def process_md_files(self, chunk_size: int = 500) -> List[Dict[str, str]]:
        """
        Process all .md files in the doc folder with chunking
        """
        md_files = list(self.doc_folder.glob("*.md"))
        logger.info(f"Found {len(md_files)} .md files")

        processed_chunks = []
        for filepath in md_files:
            file_data = self.read_md_file(filepath)

            if "error" not in file_data:
                # Chunk the content
                chunks = self.chunk_text(file_data["content"], chunk_size)

                for i, chunk in enumerate(chunks):
                    chunk_data = {
                        "filename": file_data["filename"],
                        "chunk_id": i,
                        "content": chunk,
                        "type": "md_chunk",
                        "source_file": str(filepath)
                    }
                    processed_chunks.append(chunk_data)
            else:
                processed_chunks.append(file_data)

        return processed_chunks

    def get_all_documents(self) -> Tuple[List[Dict[str, str]], List[Dict[str, str]]]:
        """
        Get all processed documents from both folders
        Returns: (osc_documents, md_documents)
        """
        osc_docs = self.process_osc_files()
        md_docs = self.process_md_files()

        logger.info(f"Processed {len(osc_docs)} .osc files and {len(md_docs)} .md chunks")

        return osc_docs, md_docs

if __name__ == "__main__":
    # Example usage
    processor = DocumentProcessor()

    # Create example files for testing
    os.makedirs("data", exist_ok=True)
    os.makedirs("doc", exist_ok=True)

    # Example .osc file
    example_osc = """import osc.types
import osc.helpers

scenario highway_lane_change:
    # Simple lane change scenario
    do parallel:
        ego_vehicle: drive_straight(100m)
        target_vehicle: change_lane(left)
"""

    with open("data/highway_lane_change_scenario.osc", "w") as f:
        f.write(example_osc)

    # Example .md file  
    example_md = """# OpenSCENARIO Documentation

## Overview
OpenSCENARIO is a domain-specific language for describing test scenarios.

## Basic Concepts
- **Scenarios**: Define test cases
- **Actions**: Define vehicle behaviors  
- **Conditions**: Define trigger conditions

## Example Usage
Use the import statement to include libraries.
"""

    with open("doc/openscenario_guide.md", "w") as f:
        f.write(example_md)

    print("Created example files for testing")

    # Test the processor
    osc_docs, md_docs = processor.get_all_documents()
    print(f"\nProcessed {len(osc_docs)} OSC documents and {len(md_docs)} MD chunks")

    if osc_docs:
        print(f"\nExample OSC document:")
        print(f"Filename: {osc_docs[0]['filename']}")
        print(f"Keywords: {osc_docs[0].get('keywords', [])}")
        print(f"Description: {osc_docs[0].get('description', '')}")

    if md_docs:
        print(f"\nExample MD chunk:")
        print(f"Content: {md_docs[0]['content'][:100]}...")
