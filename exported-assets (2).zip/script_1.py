# Now let's create the configuration files and setup scripts

# 1. DeepSpeed Configuration 
deepspeed_config = {
    "fp16": {
        "enabled": "auto",
        "loss_scale": 0,
        "loss_scale_window": 1000,
        "initial_scale_power": 16,
        "hysteresis": 2,
        "min_loss_scale": 1
    },
    "bf16": {
        "enabled": "auto"
    },
    "optimizer": {
        "type": "AdamW", 
        "params": {
            "lr": "auto",
            "betas": "auto",
            "eps": "auto",
            "weight_decay": "auto"
        }
    },
    "scheduler": {
        "type": "WarmupLR",
        "params": {
            "warmup_min_lr": "auto",
            "warmup_max_lr": "auto",
            "warmup_num_steps": "auto"
        }
    },
    "zero_optimization": {
        "stage": 3,
        "offload_optimizer": {
            "device": "cpu",
            "pin_memory": True
        },
        "offload_param": {
            "device": "cpu",
            "pin_memory": True
        },
        "overlap_comm": True,
        "contiguous_gradients": True,
        "sub_group_size": 1e9,
        "reduce_bucket_size": "auto",
        "stage3_prefetch_bucket_size": "auto",
        "stage3_param_persistence_threshold": "auto",
        "stage3_max_live_parameters": 1e9,
        "stage3_max_reuse_distance": 1e9,
        "gather_16bit_weights_on_model_save": True
    },
    "gradient_accumulation_steps": "auto",
    "gradient_clipping": "auto",
    "steps_per_print": 100,
    "train_batch_size": "auto",
    "train_micro_batch_size_per_gpu": "auto",
    "wall_clock_breakdown": False
}

with open('llama4_finetuning/configs/deepspeed_config.json', 'w') as f:
    json.dump(deepspeed_config, f, indent=2)

# 2. Training Configuration YAML
training_config_yaml = '''# LLaMA 4 Fine-tuning Configuration
# Production-grade setup for 8x A100 80GB GPUs

model:
  name_or_path: "meta-llama/Llama-4-Scout-17B-16E-Instruct"  # or Maverick
  torch_dtype: "bfloat16"
  use_flash_attention: true
  trust_remote_code: true
  cache_dir: "./cache"

# LoRA Configuration
lora:
  r: 128                    # LoRA rank - higher for complex tasks
  alpha: 256                # LoRA alpha - typically 2x rank
  dropout: 0.05            # LoRA dropout
  target_modules:
    - "q_proj"
    - "k_proj" 
    - "v_proj"
    - "o_proj"
    - "gate_proj"
    - "up_proj"
    - "down_proj"
  bias: "none"
  task_type: "CAUSAL_LM"

# Quantization
quantization:
  use_qlora: true
  load_in_4bit: true
  bnb_4bit_compute_dtype: "bfloat16"
  bnb_4bit_use_double_quant: true
  bnb_4bit_quant_type: "nf4"

# Dataset Configuration
dataset:
  path: "./data/alpaca_dataset.json"  # Path to your Alpaca format dataset
  validation_split: 0.1               # 10% for validation
  max_seq_length: 2048               # Maximum sequence length
  num_workers: 4                     # Preprocessing workers

# Training Parameters
training:
  output_dir: "./checkpoints/llama4-alpaca-lora"
  num_train_epochs: 3
  per_device_train_batch_size: 2     # Adjust based on memory
  per_device_eval_batch_size: 2
  gradient_accumulation_steps: 8     # Effective batch size = 2*8*8 = 128
  learning_rate: 1e-4
  weight_decay: 0.01
  warmup_ratio: 0.05
  lr_scheduler_type: "cosine"
  
  # Memory optimization
  gradient_checkpointing: true
  dataloader_pin_memory: false
  dataloader_num_workers: 4
  
  # Evaluation and saving
  eval_strategy: "steps"
  eval_steps: 500
  save_strategy: "steps" 
  save_steps: 500
  save_total_limit: 3
  load_best_model_at_end: true
  metric_for_best_model: "eval_loss"
  
  # Logging
  logging_dir: "./logs"
  logging_steps: 50
  report_to: ["tensorboard"]
  
  # Distributed training
  ddp_find_unused_parameters: false
  ddp_backend: "nccl"
  
# Custom Loss Configuration
custom_loss:
  use_custom_loss: true
  ce_weight: 1.0           # Cross-entropy loss weight
  syntax_weight: 0.2       # Syntax error penalty weight
  semantic_weight: 0.1     # Semantic error penalty weight  
  parser_weight: 0.05      # Parser structure awareness weight

# Tracking and Monitoring
tracking:
  use_tensorboard: true
  tensorboard_dir: "./logs/tensorboard"
  save_metrics_csv: true
  plot_metrics: true
  use_wandb: false         # Disabled for air-gapped environment
  
# Hardware Configuration
hardware:
  num_gpus: 8
  gpu_memory_gb: 80
  use_deepspeed: true
  deepspeed_config: "./configs/deepspeed_config.json"
'''

with open('llama4_finetuning/configs/training_config.yaml', 'w') as f:
    f.write(training_config_yaml)

# 3. Setup Environment Script
setup_script = '''#!/usr/bin/env python3
"""
Environment setup script for LLaMA 4 fine-tuning
Installs all required dependencies and sets up the environment
"""

import os
import sys
import subprocess
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run_command(cmd, check=True, shell=True):
    """Run shell command with error handling"""
    logger.info(f"Running: {cmd}")
    try:
        result = subprocess.run(cmd, shell=shell, check=check, capture_output=True, text=True)
        if result.stdout:
            logger.info(result.stdout)
        return result
    except subprocess.CalledProcessError as e:
        logger.error(f"Command failed: {e}")
        if e.stderr:
            logger.error(f"Error output: {e.stderr}")
        if check:
            raise
        return e

def check_cuda():
    """Check CUDA installation"""
    try:
        result = run_command("nvidia-smi", check=False)
        if result.returncode == 0:
            logger.info("✅ CUDA is available")
            logger.info(result.stdout.split('\\n')[0])  # Show driver version line
        else:
            logger.error("❌ CUDA not available or nvidia-smi failed")
            return False
    except FileNotFoundError:
        logger.error("❌ nvidia-smi not found. Please install NVIDIA drivers.")
        return False
    return True

def setup_conda_env():
    """Setup conda environment"""
    env_name = "llama4_finetuning"
    
    logger.info(f"Setting up conda environment: {env_name}")
    
    # Create conda environment  
    run_command(f"conda create -n {env_name} python=3.10 -y")
    
    # Activate environment (note: this doesn't work in subprocess, user needs to do this)
    logger.info(f"\\n⚠️  Please run: conda activate {env_name}")
    logger.info("Then continue with the installation by running this script again.")
    
    return env_name

def install_pytorch():
    """Install PyTorch with CUDA 12.1 support"""
    logger.info("Installing PyTorch with CUDA 12.1 support...")
    
    pytorch_cmd = (
        "pip install torch==2.1.0 torchvision==0.16.0 torchaudio==2.1.0 "
        "--index-url https://download.pytorch.org/whl/cu121"
    )
    run_command(pytorch_cmd)
    
    # Verify PyTorch installation
    verify_cmd = '''python -c "import torch; print(f'PyTorch: {torch.__version__}'); print(f'CUDA available: {torch.cuda.is_available()}'); print(f'GPUs: {torch.cuda.device_count()}')"'''
    run_command(verify_cmd)

def install_transformers():
    """Install Transformers and related libraries"""
    logger.info("Installing Transformers ecosystem...")
    
    # Install specific versions for stability
    packages = [
        "transformers>=4.44.0",
        "datasets>=2.14.0", 
        "tokenizers>=0.13.0",
        "accelerate>=0.24.0",
        "peft>=0.6.0",
        "bitsandbytes>=0.41.0",
        "scipy",
        "scikit-learn"
    ]
    
    for package in packages:
        run_command(f"pip install {package}")

def install_deepspeed():
    """Install DeepSpeed"""
    logger.info("Installing DeepSpeed...")
    
    # Install DeepSpeed
    run_command("pip install deepspeed>=0.12.0")
    
    # Verify installation
    run_command('python -c "import deepspeed; print(f\\"DeepSpeed version: {deepspeed.__version__}\\")"')

def install_additional_packages():
    """Install additional required packages"""
    logger.info("Installing additional packages...")
    
    packages = [
        "tensorboard>=2.14.0",
        "matplotlib>=3.7.0", 
        "seaborn>=0.12.0",
        "pandas>=2.0.0",
        "numpy>=1.24.0",
        "tqdm>=4.65.0",
        "PyYAML>=6.0",
        "wandb",  # Optional, for W&B users
        "py-osc2"  # For OpenSCENARIO parsing
    ]
    
    for package in packages:
        try:
            run_command(f"pip install {package}", check=False)
        except:
            logger.warning(f"Failed to install {package}, continuing...")

def setup_directories():
    """Create necessary directories"""
    logger.info("Creating directory structure...")
    
    directories = [
        "data/raw",
        "data/processed", 
        "checkpoints",
        "logs/tensorboard",
        "logs/training",
        "results/plots",
        "results/metrics",
        "cache"
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        logger.info(f"Created directory: {directory}")

def create_sample_config():
    """Create sample configuration files"""
    logger.info("Creating sample configuration...")
    
    # Create a sample Alpaca dataset entry
    sample_data = [
        {
            "instruction": "Write a simple Python function to calculate the factorial of a number.",
            "input": "",
            "output": "def factorial(n):\\n    if n == 0 or n == 1:\\n        return 1\\n    else:\\n        return n * factorial(n - 1)"
        },
        {
            "instruction": "Explain the concept of machine learning",
            "input": "in simple terms",
            "output": "Machine learning is a subset of artificial intelligence that enables computers to learn and make decisions from data without being explicitly programmed for every task. Instead of following pre-written instructions, ML algorithms identify patterns in data and use these patterns to make predictions or decisions on new, unseen data."
        }
    ]
    
    os.makedirs("data", exist_ok=True)
    with open("data/sample_alpaca_dataset.json", "w") as f:
        json.dump(sample_data, f, indent=2)
    
    logger.info("Created sample dataset at: data/sample_alpaca_dataset.json")

def main():
    logger.info("🚀 Setting up LLaMA 4 Fine-tuning Environment")
    logger.info("=" * 50)
    
    # Check if we're in a conda environment
    if "CONDA_DEFAULT_ENV" not in os.environ:
        logger.warning("Not in a conda environment. Setting up...")
        setup_conda_env() 
        return
    
    logger.info(f"Using conda environment: {os.environ.get('CONDA_DEFAULT_ENV')}")
    
    # Check CUDA
    if not check_cuda():
        logger.error("CUDA setup issues detected. Please resolve before continuing.")
        return
    
    # Install packages
    install_pytorch()
    install_transformers() 
    install_deepspeed()
    install_additional_packages()
    
    # Setup directories
    setup_directories()
    create_sample_config()
    
    logger.info("\\n" + "=" * 50)
    logger.info("✅ Environment setup completed successfully!")
    logger.info("\\nNext steps:")
    logger.info("1. Prepare your Alpaca format dataset")
    logger.info("2. Update the configuration in configs/training_config.yaml") 
    logger.info("3. Run training with: python scripts/train_distributed.py")
    logger.info("\\nFor distributed training across 8 GPUs:")
    logger.info("torchrun --nproc_per_node=8 scripts/train_distributed.py --config configs/training_config.yaml")

if __name__ == "__main__":
    main()
'''

with open('llama4_finetuning/scripts/setup_environment.py', 'w') as f:
    f.write(setup_script)

print("✅ Created configuration files:")
print("   - configs/deepspeed_config.json")  
print("   - configs/training_config.yaml")
print("   - scripts/setup_environment.py")

# 4. Create training launch script
launch_script = '''#!/bin/bash
"""
Production-grade launch script for distributed LLaMA 4 fine-tuning
Supports both single-node and multi-node training
"""

set -e

# Configuration
NUM_GPUS=8
NUM_NODES=1
NODE_RANK=0
MASTER_ADDR="localhost"
MASTER_PORT=29500

# Model and data paths
MODEL_NAME="meta-llama/Llama-4-Scout-17B-16E-Instruct"
DATASET_PATH="./data/alpaca_dataset.json"
OUTPUT_DIR="./checkpoints/llama4-alpaca-lora"

# Training parameters
BATCH_SIZE=2
GRAD_ACCUM=8
LEARNING_RATE=1e-4
EPOCHS=3
MAX_SEQ_LEN=2048

# LoRA parameters  
LORA_R=128
LORA_ALPHA=256
LORA_DROPOUT=0.05

# Custom loss weights
CE_WEIGHT=1.0
SYNTAX_WEIGHT=0.2
SEMANTIC_WEIGHT=0.1
PARSER_WEIGHT=0.05

echo "🚀 Starting LLaMA 4 Distributed Fine-tuning"
echo "================================================="
echo "Model: $MODEL_NAME"
echo "GPUs: $NUM_GPUS"
echo "Nodes: $NUM_NODES" 
echo "Batch size: $BATCH_SIZE"
echo "Gradient accumulation: $GRAD_ACCUM"
echo "Effective batch size: $((BATCH_SIZE * GRAD_ACCUM * NUM_GPUS))"
echo "LoRA rank: $LORA_R, alpha: $LORA_ALPHA"
echo "================================================="

# Create output directory
mkdir -p $OUTPUT_DIR
mkdir -p ./logs

# Launch distributed training
torchrun \\
    --nproc_per_node=$NUM_GPUS \\
    --nnodes=$NUM_NODES \\
    --node_rank=$NODE_RANK \\
    --master_addr=$MASTER_ADDR \\
    --master_port=$MASTER_PORT \\
    scripts/train_distributed.py \\
    --model_name_or_path $MODEL_NAME \\
    --dataset_path $DATASET_PATH \\
    --output_dir $OUTPUT_DIR \\
    --num_train_epochs $EPOCHS \\
    --per_device_train_batch_size $BATCH_SIZE \\
    --per_device_eval_batch_size $BATCH_SIZE \\
    --gradient_accumulation_steps $GRAD_ACCUM \\
    --learning_rate $LEARNING_RATE \\
    --max_seq_length $MAX_SEQ_LEN \\
    --lora_r $LORA_R \\
    --lora_alpha $LORA_ALPHA \\
    --lora_dropout $LORA_DROPOUT \\
    --ce_weight $CE_WEIGHT \\
    --syntax_weight $SYNTAX_WEIGHT \\
    --semantic_weight $SEMANTIC_WEIGHT \\
    --parser_weight $PARSER_WEIGHT \\
    --use_custom_loss \\
    --use_qlora \\
    --bf16 \\
    --gradient_checkpointing \\
    --do_train \\
    --do_eval \\
    --evaluation_strategy steps \\
    --eval_steps 500 \\
    --save_strategy steps \\
    --save_steps 500 \\
    --save_total_limit 3 \\
    --logging_steps 50 \\
    --warmup_ratio 0.05 \\
    --lr_scheduler_type cosine \\
    --weight_decay 0.01 \\
    --deepspeed configs/deepspeed_config.json \\
    --report_to tensorboard \\
    --logging_dir ./logs \\
    --dataloader_num_workers 4 \\
    --remove_unused_columns false \\
    --ddp_find_unused_parameters false

echo "✅ Training completed!"
echo "Check results in: $OUTPUT_DIR"
echo "View logs with: tensorboard --logdir ./logs"
'''

with open('llama4_finetuning/launch_training.sh', 'w') as f:
    f.write(launch_script)

# Make the script executable
os.chmod('llama4_finetuning/launch_training.sh', 0o755)

print("   - launch_training.sh (executable)")
