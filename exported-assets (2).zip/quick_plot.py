#!/usr/bin/env python3
"""
Simple plotting utility for quick visualization during training
"""

import matplotlib.pyplot as plt
import pandas as pd
import sys
from pathlib import Path

def quick_plot(csv_file: str, output_dir: str = "./results"):
    """Create quick training plots from CSV file"""

    if not Path(csv_file).exists():
        print(f"Error: {csv_file} not found")
        return

    df = pd.read_csv(csv_file)
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)

    plt.style.use('seaborn-v0_8')

    # Simple loss plot
    fig, ax = plt.subplots(figsize=(10, 6))

    if 'train_loss' in df.columns:
        ax.plot(df['step'], df['train_loss'], label='Training Loss', linewidth=2)

    if 'eval_loss' in df.columns:
        ax.plot(df['step'], df['eval_loss'], label='Validation Loss', linewidth=2)

    ax.set_xlabel('Training Steps')
    ax.set_ylabel('Loss')
    ax.set_title('Training Progress')
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(output_dir / 'quick_loss_plot.png', dpi=150, bbox_inches='tight')
    plt.close()

    print(f"Quick plot saved to {output_dir}/quick_loss_plot.png")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        quick_plot(sys.argv[1])
    else:
        quick_plot("./logs/training_metrics.csv")
