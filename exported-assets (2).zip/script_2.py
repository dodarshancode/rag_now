# Fix the syntax error and continue creating the setup files

# Create the setup script with corrected syntax
setup_script_fixed = '''#!/usr/bin/env python3
"""
Environment setup script for LLaMA 4 fine-tuning
Installs all required dependencies and sets up the environment
"""

import os
import sys
import subprocess
import logging
import json
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run_command(cmd, check=True, shell=True):
    """Run shell command with error handling"""
    logger.info(f"Running: {cmd}")
    try:
        result = subprocess.run(cmd, shell=shell, check=check, capture_output=True, text=True)
        if result.stdout:
            logger.info(result.stdout)
        return result
    except subprocess.CalledProcessError as e:
        logger.error(f"Command failed: {e}")
        if e.stderr:
            logger.error(f"Error output: {e.stderr}")
        if check:
            raise
        return e

def check_cuda():
    """Check CUDA installation"""
    try:
        result = run_command("nvidia-smi", check=False)
        if result.returncode == 0:
            logger.info("✅ CUDA is available")
            logger.info(result.stdout.split('\\n')[0])  # Show driver version line
        else:
            logger.error("❌ CUDA not available or nvidia-smi failed")
            return False
    except FileNotFoundError:
        logger.error("❌ nvidia-smi not found. Please install NVIDIA drivers.")
        return False
    return True

def install_pytorch():
    """Install PyTorch with CUDA 12.1 support"""
    logger.info("Installing PyTorch with CUDA 12.1 support...")
    
    pytorch_cmd = (
        "pip install torch==2.1.0 torchvision==0.16.0 torchaudio==2.1.0 "
        "--index-url https://download.pytorch.org/whl/cu121"
    )
    run_command(pytorch_cmd)
    
    # Verify PyTorch installation
    verify_script = """
import torch
print(f'PyTorch: {torch.__version__}')
print(f'CUDA available: {torch.cuda.is_available()}')
print(f'GPUs: {torch.cuda.device_count()}')
"""
    
    with open('verify_pytorch.py', 'w') as f:
        f.write(verify_script)
    
    run_command('python verify_pytorch.py')
    os.remove('verify_pytorch.py')

def install_transformers():
    """Install Transformers and related libraries"""
    logger.info("Installing Transformers ecosystem...")
    
    packages = [
        "transformers>=4.44.0",
        "datasets>=2.14.0", 
        "tokenizers>=0.13.0",
        "accelerate>=0.24.0",
        "peft>=0.6.0",
        "bitsandbytes>=0.41.0",
        "scipy",
        "scikit-learn"
    ]
    
    for package in packages:
        run_command(f"pip install {package}")

def install_deepspeed():
    """Install DeepSpeed"""
    logger.info("Installing DeepSpeed...")
    
    # Install DeepSpeed
    run_command("pip install deepspeed>=0.12.0")
    
    # Verify installation
    verify_script = """
import deepspeed
print(f'DeepSpeed version: {deepspeed.__version__}')
"""
    
    with open('verify_deepspeed.py', 'w') as f:
        f.write(verify_script)
    
    run_command('python verify_deepspeed.py')
    os.remove('verify_deepspeed.py')

def install_additional_packages():
    """Install additional required packages"""
    logger.info("Installing additional packages...")
    
    packages = [
        "tensorboard>=2.14.0",
        "matplotlib>=3.7.0", 
        "seaborn>=0.12.0",
        "pandas>=2.0.0",
        "numpy>=1.24.0",
        "tqdm>=4.65.0",
        "PyYAML>=6.0",
        "wandb",  # Optional, for W&B users
        "py-osc2"  # For OpenSCENARIO parsing
    ]
    
    for package in packages:
        try:
            run_command(f"pip install {package}", check=False)
        except:
            logger.warning(f"Failed to install {package}, continuing...")

def setup_directories():
    """Create necessary directories"""
    logger.info("Creating directory structure...")
    
    directories = [
        "data/raw",
        "data/processed", 
        "checkpoints",
        "logs/tensorboard",
        "logs/training",
        "results/plots",
        "results/metrics",
        "cache"
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        logger.info(f"Created directory: {directory}")

def create_sample_config():
    """Create sample configuration files"""
    logger.info("Creating sample configuration...")
    
    # Create a sample Alpaca dataset entry
    sample_data = [
        {
            "instruction": "Write a simple Python function to calculate the factorial of a number.",
            "input": "",
            "output": "def factorial(n):\\n    if n == 0 or n == 1:\\n        return 1\\n    else:\\n        return n * factorial(n - 1)"
        },
        {
            "instruction": "Explain the concept of machine learning",
            "input": "in simple terms",
            "output": "Machine learning is a subset of artificial intelligence that enables computers to learn and make decisions from data without being explicitly programmed for every task."
        }
    ]
    
    os.makedirs("data", exist_ok=True)
    with open("data/sample_alpaca_dataset.json", "w") as f:
        json.dump(sample_data, f, indent=2)
    
    logger.info("Created sample dataset at: data/sample_alpaca_dataset.json")

def main():
    logger.info("🚀 Setting up LLaMA 4 Fine-tuning Environment")
    logger.info("=" * 50)
    
    logger.info(f"Using Python: {sys.executable}")
    
    # Check CUDA
    if not check_cuda():
        logger.error("CUDA setup issues detected. Please resolve before continuing.")
        return
    
    # Install packages
    install_pytorch()
    install_transformers() 
    install_deepspeed()
    install_additional_packages()
    
    # Setup directories
    setup_directories()
    create_sample_config()
    
    logger.info("\\n" + "=" * 50)
    logger.info("✅ Environment setup completed successfully!")
    logger.info("\\nNext steps:")
    logger.info("1. Prepare your Alpaca format dataset")
    logger.info("2. Update the configuration in configs/training_config.yaml") 
    logger.info("3. Run training with: python scripts/train_distributed.py")
    logger.info("\\nFor distributed training across 8 GPUs:")
    logger.info("torchrun --nproc_per_node=8 scripts/train_distributed.py")

if __name__ == "__main__":
    main()
'''

# Write the corrected setup script
with open('llama4_finetuning/scripts/setup_environment.py', 'w') as f:
    f.write(setup_script_fixed)

# Create the launch script
launch_script = '''#!/bin/bash
# Production-grade launch script for distributed LLaMA 4 fine-tuning
# Supports both single-node and multi-node training

set -e

# Configuration
NUM_GPUS=8
NUM_NODES=1
NODE_RANK=0
MASTER_ADDR="localhost"
MASTER_PORT=29500

# Model and data paths
MODEL_NAME="meta-llama/Llama-4-Scout-17B-16E-Instruct"
DATASET_PATH="./data/alpaca_dataset.json"
OUTPUT_DIR="./checkpoints/llama4-alpaca-lora"

# Training parameters
BATCH_SIZE=2
GRAD_ACCUM=8
LEARNING_RATE=1e-4
EPOCHS=3
MAX_SEQ_LEN=2048

# LoRA parameters  
LORA_R=128
LORA_ALPHA=256
LORA_DROPOUT=0.05

# Custom loss weights
CE_WEIGHT=1.0
SYNTAX_WEIGHT=0.2
SEMANTIC_WEIGHT=0.1
PARSER_WEIGHT=0.05

echo "🚀 Starting LLaMA 4 Distributed Fine-tuning"
echo "================================================="
echo "Model: $MODEL_NAME"
echo "GPUs: $NUM_GPUS"
echo "Nodes: $NUM_NODES" 
echo "Batch size: $BATCH_SIZE"
echo "Gradient accumulation: $GRAD_ACCUM"
echo "Effective batch size: $((BATCH_SIZE * GRAD_ACCUM * NUM_GPUS))"
echo "LoRA rank: $LORA_R, alpha: $LORA_ALPHA"
echo "================================================="

# Create output directory
mkdir -p $OUTPUT_DIR
mkdir -p ./logs

# Launch distributed training
torchrun \\
    --nproc_per_node=$NUM_GPUS \\
    --nnodes=$NUM_NODES \\
    --node_rank=$NODE_RANK \\
    --master_addr=$MASTER_ADDR \\
    --master_port=$MASTER_PORT \\
    scripts/train_distributed.py \\
    --model_name_or_path $MODEL_NAME \\
    --dataset_path $DATASET_PATH \\
    --output_dir $OUTPUT_DIR \\
    --num_train_epochs $EPOCHS \\
    --per_device_train_batch_size $BATCH_SIZE \\
    --per_device_eval_batch_size $BATCH_SIZE \\
    --gradient_accumulation_steps $GRAD_ACCUM \\
    --learning_rate $LEARNING_RATE \\
    --max_seq_length $MAX_SEQ_LEN \\
    --lora_r $LORA_R \\
    --lora_alpha $LORA_ALPHA \\
    --lora_dropout $LORA_DROPOUT \\
    --ce_weight $CE_WEIGHT \\
    --syntax_weight $SYNTAX_WEIGHT \\
    --semantic_weight $SEMANTIC_WEIGHT \\
    --parser_weight $PARSER_WEIGHT \\
    --use_custom_loss \\
    --use_qlora \\
    --bf16 \\
    --gradient_checkpointing \\
    --do_train \\
    --do_eval \\
    --evaluation_strategy steps \\
    --eval_steps 500 \\
    --save_strategy steps \\
    --save_steps 500 \\
    --save_total_limit 3 \\
    --logging_steps 50 \\
    --warmup_ratio 0.05 \\
    --lr_scheduler_type cosine \\
    --weight_decay 0.01 \\
    --deepspeed configs/deepspeed_config.json \\
    --report_to tensorboard \\
    --logging_dir ./logs \\
    --dataloader_num_workers 4 \\
    --remove_unused_columns false \\
    --ddp_find_unused_parameters false

echo "✅ Training completed!"
echo "Check results in: $OUTPUT_DIR"
echo "View logs with: tensorboard --logdir ./logs"
'''

with open('llama4_finetuning/launch_training.sh', 'w') as f:
    f.write(launch_script)

# Make the script executable
import stat
os.chmod('llama4_finetuning/launch_training.sh', stat.S_IRWXU | stat.S_IRGRP | stat.S_IROTH)

print("✅ Created configuration and launch files:")
print("   - scripts/setup_environment.py (fixed)")
print("   - launch_training.sh (executable)")

# Create additional utility files
requirements_txt = '''# LLaMA 4 Fine-tuning Requirements
# Production-grade setup for distributed training

# Core ML libraries
torch>=2.1.0
torchvision>=0.16.0 
torchaudio>=2.1.0
transformers>=4.44.0
tokenizers>=0.13.0

# Distributed training and optimization
deepspeed>=0.12.0
accelerate>=0.24.0

# Parameter-efficient fine-tuning
peft>=0.6.0
bitsandbytes>=0.41.0

# Data handling
datasets>=2.14.0
pandas>=2.0.0
numpy>=1.24.0

# Visualization and tracking
tensorboard>=2.14.0
matplotlib>=3.7.0
seaborn>=0.12.0
wandb  # Optional for W&B users

# Utilities
tqdm>=4.65.0
PyYAML>=6.0
scipy
scikit-learn

# Parser for custom loss (OpenSCENARIO 2.x)
py-osc2

# Development tools (optional)
ipykernel  # For Jupyter notebooks
black      # Code formatting  
flake8     # Code linting
'''

with open('llama4_finetuning/requirements.txt', 'w') as f:
    f.write(requirements_txt)

# Create evaluation script
eval_script = '''#!/usr/bin/env python3
"""
Evaluation script for fine-tuned LLaMA 4 models
Generates comprehensive evaluation metrics and visualizations
"""

import os
import json
import argparse
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
import torch
from tqdm import tqdm

def load_model_and_tokenizer(base_model_path, peft_model_path=None):
    """Load base model and LoRA adapter"""
    
    tokenizer = AutoTokenizer.from_pretrained(base_model_path)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    model = AutoModelForCausalLM.from_pretrained(
        base_model_path,
        torch_dtype=torch.bfloat16,
        device_map="auto"
    )
    
    if peft_model_path:
        model = PeftModel.from_pretrained(model, peft_model_path)
        
    return model, tokenizer

def evaluate_on_dataset(model, tokenizer, dataset_path, max_examples=100):
    """Evaluate model on test dataset"""
    
    with open(dataset_path, 'r') as f:
        data = json.load(f)
        
    if len(data) > max_examples:
        data = data[:max_examples]
    
    results = []
    
    for example in tqdm(data, desc="Evaluating"):
        instruction = example['instruction']
        input_text = example.get('input', '')
        expected_output = example['output']
        
        # Format prompt
        if input_text:
            prompt = f"### Instruction:\\n{instruction}\\n\\n### Input:\\n{input_text}\\n\\n### Response:\\n"
        else:
            prompt = f"### Instruction:\\n{instruction}\\n\\n### Response:\\n"
        
        # Generate response
        inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=1024)
        
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=512,
                temperature=0.7,
                do_sample=True,
                pad_token_id=tokenizer.eos_token_id
            )
        
        generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
        response = generated_text[len(prompt):].strip()
        
        results.append({
            'instruction': instruction,
            'input': input_text,
            'expected': expected_output,
            'generated': response,
            'prompt_length': len(inputs['input_ids'][0]),
            'response_length': len(response.split())
        })
    
    return results

def create_evaluation_plots(metrics_df, output_dir):
    """Create evaluation visualization plots"""
    
    plt.style.use('seaborn-v0_8')
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Response length distribution
    axes[0,0].hist(metrics_df['response_length'], bins=30, alpha=0.7, color='skyblue')
    axes[0,0].set_title('Response Length Distribution')
    axes[0,0].set_xlabel('Number of Words')
    axes[0,0].set_ylabel('Frequency')
    
    # Prompt vs Response length
    axes[0,1].scatter(metrics_df['prompt_length'], metrics_df['response_length'], alpha=0.6)
    axes[0,1].set_title('Prompt Length vs Response Length') 
    axes[0,1].set_xlabel('Prompt Length (tokens)')
    axes[0,1].set_ylabel('Response Length (words)')
    
    # Response length by instruction type (if available)
    if 'instruction_type' in metrics_df.columns:
        sns.boxplot(data=metrics_df, x='instruction_type', y='response_length', ax=axes[1,0])
        axes[1,0].set_title('Response Length by Instruction Type')
        axes[1,0].tick_params(axis='x', rotation=45)
    else:
        axes[1,0].text(0.5, 0.5, 'Instruction Type\\nClassification\\nNot Available', 
                      ha='center', va='center', transform=axes[1,0].transAxes)
        axes[1,0].set_title('Instruction Type Analysis')
    
    # Summary statistics
    stats_text = f"""
    Evaluation Summary:
    
    Total Examples: {len(metrics_df)}
    Avg Response Length: {metrics_df['response_length'].mean():.1f} words
    Avg Prompt Length: {metrics_df['prompt_length'].mean():.1f} tokens
    
    Response Length:
    Min: {metrics_df['response_length'].min()} words
    Max: {metrics_df['response_length'].max()} words
    Std: {metrics_df['response_length'].std():.1f} words
    """
    
    axes[1,1].text(0.1, 0.9, stats_text, transform=axes[1,1].transAxes, 
                   verticalalignment='top', fontsize=10, fontfamily='monospace')
    axes[1,1].axis('off')
    axes[1,1].set_title('Summary Statistics')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'evaluation_plots.png'), dpi=300, bbox_inches='tight')
    plt.close()

def main():
    parser = argparse.ArgumentParser(description='Evaluate fine-tuned LLaMA 4 model')
    parser.add_argument('--base_model', type=str, required=True, help='Base model path')
    parser.add_argument('--peft_model', type=str, help='LoRA adapter path')
    parser.add_argument('--dataset', type=str, required=True, help='Test dataset path') 
    parser.add_argument('--output_dir', type=str, default='./results', help='Output directory')
    parser.add_argument('--max_examples', type=int, default=100, help='Maximum examples to evaluate')
    
    args = parser.parse_args()
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    print("Loading model and tokenizer...")
    model, tokenizer = load_model_and_tokenizer(args.base_model, args.peft_model)
    
    print("Running evaluation...")
    results = evaluate_on_dataset(model, tokenizer, args.dataset, args.max_examples)
    
    # Save detailed results
    results_df = pd.DataFrame(results)
    results_df.to_csv(os.path.join(args.output_dir, 'evaluation_results.csv'), index=False)
    
    print("Creating visualizations...")
    create_evaluation_plots(results_df, args.output_dir)
    
    # Save summary
    summary = {
        'total_examples': len(results),
        'avg_response_length': float(results_df['response_length'].mean()),
        'avg_prompt_length': float(results_df['prompt_length'].mean()),
        'response_length_std': float(results_df['response_length'].std())
    }
    
    with open(os.path.join(args.output_dir, 'evaluation_summary.json'), 'w') as f:
        json.dump(summary, f, indent=2)
    
    print(f"✅ Evaluation completed!")
    print(f"Results saved to: {args.output_dir}")
    print(f"Summary: {summary}")

if __name__ == "__main__":
    main()
'''

with open('llama4_finetuning/scripts/evaluate.py', 'w') as f:
    f.write(eval_script)

print("✅ Created additional files:")
print("   - requirements.txt")
print("   - scripts/evaluate.py")