# Let me create a comprehensive production-grade fine-tuning setup for LLaMA 4 models
# Starting with the main training script

import os
import json
import logging
from pathlib import Path

# Create directory structure for the fine-tuning project
project_structure = {
    'llama4_finetuning/': {
        'src/': {
            'models/': ['__init__.py', 'llama4_model.py', 'custom_trainer.py'],
            'data/': ['__init__.py', 'data_loader.py', 'preprocessor.py'],
            'losses/': ['__init__.py', 'custom_loss.py', 'parser_loss.py'],
            'utils/': ['__init__.py', 'tracker.py', 'helpers.py'],
        },
        'configs/': ['training_config.yaml', 'model_config.yaml', 'deepspeed_config.json'],
        'scripts/': ['setup_environment.py', 'train_distributed.py', 'evaluate.py'],
        'notebooks/': ['data_analysis.ipynb', 'results_visualization.ipynb'],
        'data/': ['processed/', 'raw/'],
        'logs/': ['training/', 'tensorboard/'],
        'checkpoints/': ['best_model/', 'latest/'],
        'results/': ['plots/', 'metrics/'],
    }
}

def create_structure(base_path, structure, current_path=""):
    """Create directory structure"""
    for name, content in structure.items():
        full_path = os.path.join(base_path, current_path, name)
        
        if isinstance(content, dict):
            os.makedirs(full_path, exist_ok=True)
            create_structure(base_path, content, os.path.join(current_path, name))
        elif isinstance(content, list):
            os.makedirs(full_path, exist_ok=True)
            for file_name in content:
                if file_name.endswith('.py'):
                    file_path = os.path.join(full_path, file_name)
                    with open(file_path, 'w') as f:
                        f.write(f'# {file_name}\n')

# Create the project structure
base_path = "."
create_structure(base_path, project_structure)

print("✅ Created complete project directory structure")

# Now let's create a comprehensive training script
training_script = '''#!/usr/bin/env python3
"""
Production-grade LLaMA 4 Fine-tuning with Custom Parser-Aware Loss Functions
Author: AI Research Assistant
Date: September 2025

This script provides distributed fine-tuning capabilities for LLaMA 4 models
with custom loss functions that incorporate parser knowledge for syntax and 
semantic error detection.
"""

import os
import sys
import json
import logging
import argparse
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
import warnings

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, DistributedSampler
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP

import transformers
from transformers import (
    AutoTokenizer, 
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling,
    get_linear_schedule_with_warmup,
    set_seed
)
from transformers.trainer_utils import get_last_checkpoint
from transformers.utils import check_min_version

from peft import (
    LoraConfig, 
    get_peft_model, 
    TaskType, 
    prepare_model_for_kbit_training
)
from peft.utils import _get_submodules

import bitsandbytes as bnb
from datasets import load_dataset
import numpy as np
from tqdm import tqdm
import wandb
from tensorboard import SummaryWriter

# Custom imports
try:
    from py_osc2 import parse_osc2_file, get_syntax_errors, get_semantic_errors
    OSC2_AVAILABLE = True
except ImportError:
    OSC2_AVAILABLE = False
    warnings.warn("py-osc2 not available. Parser-aware loss will be disabled.")

# Ensure we're using the right transformers version
check_min_version("4.44.0")

# Configure logging
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

@dataclass
class ModelArguments:
    """Arguments pertaining to which model/config/tokenizer we are going to fine-tune."""
    model_name_or_path: str = field(
        metadata={"help": "Path to pretrained model or model identifier from huggingface.co/models"}
    )
    cache_dir: Optional[str] = field(
        default=None, 
        metadata={"help": "Where to store the pretrained models downloaded from huggingface.co"}
    )
    use_fast_tokenizer: bool = field(
        default=True,
        metadata={"help": "Whether to use one of the fast tokenizer (backed by the tokenizers library) or not."}
    )
    model_revision: str = field(
        default="main",
        metadata={"help": "The specific model version to use (can be a branch name, tag name or commit id)."}
    )
    torch_dtype: Optional[str] = field(
        default=None,
        metadata={"help": "Override the default `torch.dtype` and load the model under this dtype."}
    )
    use_qlora: bool = field(
        default=True,
        metadata={"help": "Whether to use QLoRA for parameter-efficient fine-tuning"}
    )
    
@dataclass
class DataTrainingArguments:
    """Arguments pertaining to what data we are going to input our model for training and eval."""
    dataset_name: Optional[str] = field(
        default=None, 
        metadata={"help": "The name of the dataset to use (via the datasets library)."}
    )
    dataset_path: Optional[str] = field(
        default=None,
        metadata={"help": "Path to the training dataset (JSON file in Alpaca format)."}
    )
    validation_split_percentage: int = field(
        default=10,
        metadata={"help": "The percentage of the train set used as validation set."}
    )
    max_seq_length: int = field(
        default=2048,
        metadata={"help": "The maximum total input sequence length after tokenization."}
    )
    preprocessing_num_workers: Optional[int] = field(
        default=None,
        metadata={"help": "The number of processes to use for the preprocessing."}
    )
    overwrite_cache: bool = field(
        default=False, 
        metadata={"help": "Overwrite the cached training and evaluation sets"}
    )

@dataclass
class LoraArguments:
    """Arguments for LoRA configuration"""
    lora_r: int = field(default=128, metadata={"help": "LoRA rank"})
    lora_alpha: int = field(default=256, metadata={"help": "LoRA alpha"}) 
    lora_dropout: float = field(default=0.05, metadata={"help": "LoRA dropout"})
    lora_target_modules: List[str] = field(
        default_factory=lambda: ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        metadata={"help": "Target modules for LoRA"}
    )
    lora_bias: str = field(default="none", metadata={"help": "LoRA bias"})
    lora_task_type: str = field(default="CAUSAL_LM", metadata={"help": "LoRA task type"})

@dataclass 
class CustomLossArguments:
    """Arguments for custom loss function configuration"""
    use_custom_loss: bool = field(default=True, metadata={"help": "Whether to use custom loss function"})
    ce_weight: float = field(default=1.0, metadata={"help": "Weight for cross-entropy loss"})
    syntax_weight: float = field(default=0.2, metadata={"help": "Weight for syntax error loss"})  
    semantic_weight: float = field(default=0.1, metadata={"help": "Weight for semantic error loss"})
    parser_weight: float = field(default=0.05, metadata={"help": "Weight for parser structure loss"})
    
@dataclass
class TrackingArguments:
    """Arguments for training tracking"""
    use_tensorboard: bool = field(default=True, metadata={"help": "Whether to use TensorBoard for tracking"})
    use_wandb: bool = field(default=False, metadata={"help": "Whether to use Weights & Biases"})
    tensorboard_dir: str = field(default="./logs/tensorboard", metadata={"help": "TensorBoard log directory"})
    save_metrics_csv: bool = field(default=True, metadata={"help": "Whether to save metrics to CSV"})
    plot_metrics: bool = field(default=True, metadata={"help": "Whether to generate metric plots"})


class ParserAwareLoss(nn.Module):
    """
    Custom loss function that combines:
    1. Standard cross-entropy loss
    2. Syntax error penalty 
    3. Semantic error penalty
    4. Parser structure awareness
    """
    
    def __init__(
        self, 
        tokenizer,
        ce_weight: float = 1.0,
        syntax_weight: float = 0.2, 
        semantic_weight: float = 0.1,
        parser_weight: float = 0.05,
        vocab_size: int = None
    ):
        super().__init__()
        self.tokenizer = tokenizer
        self.ce_weight = ce_weight
        self.syntax_weight = syntax_weight
        self.semantic_weight = semantic_weight  
        self.parser_weight = parser_weight
        self.vocab_size = vocab_size or len(tokenizer)
        
        # Standard cross-entropy loss
        self.ce_loss = nn.CrossEntropyLoss(ignore_index=-100)
        
    def forward(
        self, 
        logits: torch.Tensor,
        labels: torch.Tensor, 
        input_ids: torch.Tensor = None,
        **kwargs
    ) -> torch.Tensor:
        """
        Compute the combined loss
        
        Args:
            logits: Model output logits [batch_size, seq_len, vocab_size]
            labels: Target labels [batch_size, seq_len] 
            input_ids: Input token ids [batch_size, seq_len]
            
        Returns:
            Combined loss tensor
        """
        # Standard cross-entropy loss
        ce_loss = self.ce_loss(logits.view(-1, logits.size(-1)), labels.view(-1))
        total_loss = self.ce_weight * ce_loss
        
        # Add syntax and semantic losses if parser is available
        if OSC2_AVAILABLE and input_ids is not None:
            try:
                syntax_loss = self._compute_syntax_loss(logits, labels, input_ids)
                semantic_loss = self._compute_semantic_loss(logits, labels, input_ids)
                parser_loss = self._compute_parser_structure_loss(logits, labels, input_ids)
                
                total_loss += self.syntax_weight * syntax_loss
                total_loss += self.semantic_weight * semantic_loss  
                total_loss += self.parser_weight * parser_loss
                
            except Exception as e:
                # Fallback to CE loss if parser fails
                logger.warning(f"Parser-aware loss computation failed: {e}")
                
        return total_loss
        
    def _compute_syntax_loss(
        self, 
        logits: torch.Tensor, 
        labels: torch.Tensor,
        input_ids: torch.Tensor
    ) -> torch.Tensor:
        """Compute syntax error penalty loss"""
        batch_size = input_ids.size(0)
        syntax_losses = []
        
        for i in range(batch_size):
            # Decode the generated text
            decoded_text = self.tokenizer.decode(input_ids[i], skip_special_tokens=True)
            
            try:
                # Check for syntax errors using py-osc2
                syntax_errors = get_syntax_errors(decoded_text)
                
                # Penalize positions with syntax errors
                error_penalty = len(syntax_errors) / max(len(decoded_text.split()), 1)
                syntax_losses.append(error_penalty)
                
            except:
                syntax_losses.append(0.0)
        
        return torch.tensor(np.mean(syntax_losses), device=logits.device, dtype=logits.dtype)
    
    def _compute_semantic_loss(
        self,
        logits: torch.Tensor,
        labels: torch.Tensor, 
        input_ids: torch.Tensor
    ) -> torch.Tensor:
        """Compute semantic error penalty loss"""
        batch_size = input_ids.size(0)
        semantic_losses = []
        
        for i in range(batch_size):
            decoded_text = self.tokenizer.decode(input_ids[i], skip_special_tokens=True)
            
            try:
                # Check for semantic errors
                semantic_errors = get_semantic_errors(decoded_text)
                error_penalty = len(semantic_errors) / max(len(decoded_text.split()), 1)
                semantic_losses.append(error_penalty)
                
            except:
                semantic_losses.append(0.0)
                
        return torch.tensor(np.mean(semantic_losses), device=logits.device, dtype=logits.dtype)
    
    def _compute_parser_structure_loss(
        self,
        logits: torch.Tensor, 
        labels: torch.Tensor,
        input_ids: torch.Tensor
    ) -> torch.Tensor:
        """Compute parser structure awareness loss"""
        # This could be expanded to include AST-based structural penalties
        # For now, return a simple structural consistency metric
        return torch.tensor(0.0, device=logits.device, dtype=logits.dtype)


class CustomTrainer(Trainer):
    """Custom trainer with parser-aware loss function and enhanced tracking"""
    
    def __init__(self, custom_loss_fn=None, tracking_args=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.custom_loss_fn = custom_loss_fn
        self.tracking_args = tracking_args or TrackingArguments()
        
        # Initialize TensorBoard writer
        if self.tracking_args.use_tensorboard:
            self.tb_writer = SummaryWriter(log_dir=self.tracking_args.tensorboard_dir)
        
        # Metrics storage for CSV export
        self.training_metrics = []
        
    def compute_loss(self, model, inputs, return_outputs=False):
        """Override compute_loss to use custom loss function"""
        labels = inputs.get("labels")
        
        # Forward pass
        outputs = model(**inputs)
        
        if self.custom_loss_fn is not None:
            # Use custom loss function
            loss = self.custom_loss_fn(
                logits=outputs.logits,
                labels=labels,
                input_ids=inputs.get("input_ids"),
            )
        else:
            # Use default loss
            loss = outputs.loss if hasattr(outputs, 'loss') else outputs[0]
            
        return (loss, outputs) if return_outputs else loss
    
    def log(self, logs: Dict[str, float]) -> None:
        """Enhanced logging with TensorBoard and CSV export"""
        super().log(logs)
        
        # Log to TensorBoard
        if self.tracking_args.use_tensorboard and hasattr(self, 'tb_writer'):
            for key, value in logs.items():
                if isinstance(value, (int, float)):
                    self.tb_writer.add_scalar(key, value, self.state.global_step)
        
        # Store metrics for CSV export
        if self.tracking_args.save_metrics_csv:
            metric_entry = {'step': self.state.global_step, **logs}
            self.training_metrics.append(metric_entry)
    
    def save_training_metrics(self, output_dir: str):
        """Save training metrics to CSV file"""
        if self.training_metrics:
            import pandas as pd
            df = pd.DataFrame(self.training_metrics)
            df.to_csv(os.path.join(output_dir, 'training_metrics.csv'), index=False)
            logger.info(f"Saved training metrics to {output_dir}/training_metrics.csv")


def setup_distributed():
    """Setup distributed training"""
    if 'RANK' in os.environ and 'WORLD_SIZE' in os.environ:
        rank = int(os.environ["RANK"])
        world_size = int(os.environ['WORLD_SIZE'])
        gpu = int(os.environ['LOCAL_RANK'])
    elif 'SLURM_PROCID' in os.environ:
        rank = int(os.environ['SLURM_PROCID'])
        gpu = rank % torch.cuda.device_count()
        world_size = int(os.environ['SLURM_NPROCS'])
    else:
        print('Not using distributed mode')
        return False, 0, 1
        
    torch.cuda.set_device(gpu)
    dist.init_process_group(
        backend='nccl', 
        init_method='env://',
        world_size=world_size, 
        rank=rank
    )
    dist.barrier()
    
    return True, rank, world_size


def create_lora_model(model, lora_args: LoraArguments):
    """Create LoRA model configuration"""
    
    # Prepare model for k-bit training if using quantization
    if hasattr(model, 'gradient_checkpointing_enable'):
        model.gradient_checkpointing_enable()
    
    model = prepare_model_for_kbit_training(model)
    
    # LoRA configuration
    lora_config = LoraConfig(
        r=lora_args.lora_r,
        lora_alpha=lora_args.lora_alpha,
        target_modules=lora_args.lora_target_modules,
        lora_dropout=lora_args.lora_dropout,
        bias=lora_args.lora_bias,
        task_type=getattr(TaskType, lora_args.lora_task_type)
    )
    
    # Apply LoRA
    model = get_peft_model(model, lora_config)
    
    # Print trainable parameters
    model.print_trainable_parameters()
    
    return model


def load_and_prepare_dataset(data_args: DataTrainingArguments, tokenizer):
    """Load and prepare the Alpaca dataset"""
    
    if data_args.dataset_path:
        # Load from local JSON file  
        with open(data_args.dataset_path, 'r') as f:
            data = json.load(f)
            
        # Convert to datasets format
        from datasets import Dataset
        dataset = Dataset.from_list(data)
    else:
        # Load from HuggingFace
        dataset = load_dataset(data_args.dataset_name)['train']
    
    def format_prompt(example):
        """Format the prompt in Alpaca style"""
        instruction = example.get('instruction', '')
        input_text = example.get('input', '') 
        output = example.get('output', '')
        
        if input_text:
            prompt = f"### Instruction:\\n{instruction}\\n\\n### Input:\\n{input_text}\\n\\n### Response:\\n{output}"
        else:
            prompt = f"### Instruction:\\n{instruction}\\n\\n### Response:\\n{output}"
            
        return {'text': prompt}
    
    # Format all examples
    dataset = dataset.map(format_prompt)
    
    def tokenize_function(examples):
        """Tokenize the dataset"""
        outputs = tokenizer(
            examples['text'],
            truncation=True,
            padding=False,
            max_length=data_args.max_seq_length,
            return_overflowing_tokens=False,
        )
        outputs['labels'] = outputs['input_ids'].copy()
        return outputs
    
    # Tokenize dataset
    tokenized_dataset = dataset.map(
        tokenize_function,
        batched=True,
        num_proc=data_args.preprocessing_num_workers,
        remove_columns=dataset.column_names,
        load_from_cache_file=not data_args.overwrite_cache,
    )
    
    # Split into train/validation
    if data_args.validation_split_percentage > 0:
        split_dataset = tokenized_dataset.train_test_split(
            test_size=data_args.validation_split_percentage / 100
        )
        train_dataset = split_dataset['train']
        eval_dataset = split_dataset['test'] 
    else:
        train_dataset = tokenized_dataset
        eval_dataset = None
    
    return train_dataset, eval_dataset


def main():
    # Parse arguments
    parser = transformers.HfArgumentParser((
        ModelArguments, 
        DataTrainingArguments, 
        TrainingArguments,
        LoraArguments,
        CustomLossArguments,
        TrackingArguments
    ))
    
    (model_args, data_args, training_args, lora_args, 
     custom_loss_args, tracking_args) = parser.parse_args_into_dataclasses()
    
    # Setup distributed training
    is_distributed, rank, world_size = setup_distributed()
    
    # Set seed
    set_seed(training_args.seed)
    
    # Setup logging
    if rank == 0:
        logger.info("*** Starting LLaMA 4 Fine-tuning ***")
        logger.info(f"Training arguments: {training_args}")
        logger.info(f"Model arguments: {model_args}")
        logger.info(f"LoRA arguments: {lora_args}")
        
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(
        model_args.model_name_or_path,
        cache_dir=model_args.cache_dir,
        use_fast=model_args.use_fast_tokenizer,
        revision=model_args.model_revision,
        trust_remote_code=True
    )
    
    # Add padding token if missing
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        
    # Load model with quantization if requested
    torch_dtype = (
        model_args.torch_dtype 
        if model_args.torch_dtype in ["auto", None]
        else getattr(torch, model_args.torch_dtype)
    )
    
    quantization_config = None
    if model_args.use_qlora:
        from transformers import BitsAndBytesConfig
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch_dtype,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4"
        )
    
    model = AutoModelForCausalLM.from_pretrained(
        model_args.model_name_or_path,
        cache_dir=model_args.cache_dir,
        revision=model_args.model_revision,
        torch_dtype=torch_dtype,
        quantization_config=quantization_config,
        device_map="auto" if not is_distributed else None,
        trust_remote_code=True
    )
    
    # Apply LoRA
    if model_args.use_qlora:
        model = create_lora_model(model, lora_args)
    
    # Load and prepare dataset  
    train_dataset, eval_dataset = load_and_prepare_dataset(data_args, tokenizer)
    
    if rank == 0:
        logger.info(f"Train dataset size: {len(train_dataset)}")
        if eval_dataset:
            logger.info(f"Eval dataset size: {len(eval_dataset)}")
    
    # Data collator
    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False,
        return_tensors="pt",
        pad_to_multiple_of=8
    )
    
    # Initialize custom loss function
    custom_loss_fn = None
    if custom_loss_args.use_custom_loss:
        custom_loss_fn = ParserAwareLoss(
            tokenizer=tokenizer,
            ce_weight=custom_loss_args.ce_weight,
            syntax_weight=custom_loss_args.syntax_weight, 
            semantic_weight=custom_loss_args.semantic_weight,
            parser_weight=custom_loss_args.parser_weight
        )
        
        if rank == 0:
            logger.info("Initialized custom parser-aware loss function")
    
    # Initialize trainer
    trainer = CustomTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=data_collator,
        custom_loss_fn=custom_loss_fn,
        tracking_args=tracking_args
    )
    
    # Training
    if training_args.do_train:
        if rank == 0:
            logger.info("*** Starting training ***")
            
        checkpoint = None
        if training_args.resume_from_checkpoint is not None:
            checkpoint = training_args.resume_from_checkpoint
        elif last_checkpoint := get_last_checkpoint(training_args.output_dir):
            checkpoint = last_checkpoint
            
        train_result = trainer.train(resume_from_checkpoint=checkpoint)
        
        # Save model
        trainer.save_model()
        
        # Save training metrics
        if rank == 0:
            trainer.save_training_metrics(training_args.output_dir)
            
        if rank == 0:
            logger.info("*** Training completed ***")
            logger.info(f"Training results: {train_result}")
    
    # Evaluation  
    if training_args.do_eval and eval_dataset:
        if rank == 0:
            logger.info("*** Running evaluation ***")
            
        eval_results = trainer.evaluate()
        
        if rank == 0:
            logger.info(f"Evaluation results: {eval_results}")
    
    # Cleanup
    if hasattr(trainer, 'tb_writer'):
        trainer.tb_writer.close()
        
    if is_distributed:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
'''

# Save the training script
with open('llama4_finetuning/scripts/train_distributed.py', 'w') as f:
    f.write(training_script)

print("✅ Created comprehensive training script with custom loss functions")
print("✅ Training script saved to: llama4_finetuning/scripts/train_distributed.py")