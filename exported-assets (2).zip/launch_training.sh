#!/bin/bash
# Production-grade launch script for distributed LLaMA 4 fine-tuning
# Supports both single-node and multi-node training

set -e

# Configuration
NUM_GPUS=8
NUM_NODES=1
NODE_RANK=0
MASTER_ADDR="localhost"
MASTER_PORT=29500

# Model and data paths
MODEL_NAME="meta-llama/Llama-4-Scout-17B-16E-Instruct"
DATASET_PATH="./data/alpaca_dataset.json"
OUTPUT_DIR="./checkpoints/llama4-alpaca-lora"

# Training parameters
BATCH_SIZE=2
GRAD_ACCUM=8
LEARNING_RATE=1e-4
EPOCHS=3
MAX_SEQ_LEN=2048

# LoRA parameters  
LORA_R=128
LORA_ALPHA=256
LORA_DROPOUT=0.05

# Custom loss weights
CE_WEIGHT=1.0
SYNTAX_WEIGHT=0.2
SEMANTIC_WEIGHT=0.1
PARSER_WEIGHT=0.05

echo "🚀 Starting LLaMA 4 Distributed Fine-tuning"
echo "================================================="
echo "Model: $MODEL_NAME"
echo "GPUs: $NUM_GPUS"
echo "Nodes: $NUM_NODES" 
echo "Batch size: $BATCH_SIZE"
echo "Gradient accumulation: $GRAD_ACCUM"
echo "Effective batch size: $((BATCH_SIZE * GRAD_ACCUM * NUM_GPUS))"
echo "LoRA rank: $LORA_R, alpha: $LORA_ALPHA"
echo "================================================="

# Create output directory
mkdir -p $OUTPUT_DIR
mkdir -p ./logs

# Launch distributed training
torchrun \
    --nproc_per_node=$NUM_GPUS \
    --nnodes=$NUM_NODES \
    --node_rank=$NODE_RANK \
    --master_addr=$MASTER_ADDR \
    --master_port=$MASTER_PORT \
    scripts/train_distributed.py \
    --model_name_or_path $MODEL_NAME \
    --dataset_path $DATASET_PATH \
    --output_dir $OUTPUT_DIR \
    --num_train_epochs $EPOCHS \
    --per_device_train_batch_size $BATCH_SIZE \
    --per_device_eval_batch_size $BATCH_SIZE \
    --gradient_accumulation_steps $GRAD_ACCUM \
    --learning_rate $LEARNING_RATE \
    --max_seq_length $MAX_SEQ_LEN \
    --lora_r $LORA_R \
    --lora_alpha $LORA_ALPHA \
    --lora_dropout $LORA_DROPOUT \
    --ce_weight $CE_WEIGHT \
    --syntax_weight $SYNTAX_WEIGHT \
    --semantic_weight $SEMANTIC_WEIGHT \
    --parser_weight $PARSER_WEIGHT \
    --use_custom_loss \
    --use_qlora \
    --bf16 \
    --gradient_checkpointing \
    --do_train \
    --do_eval \
    --evaluation_strategy steps \
    --eval_steps 500 \
    --save_strategy steps \
    --save_steps 500 \
    --save_total_limit 3 \
    --logging_steps 50 \
    --warmup_ratio 0.05 \
    --lr_scheduler_type cosine \
    --weight_decay 0.01 \
    --deepspeed configs/deepspeed_config.json \
    --report_to tensorboard \
    --logging_dir ./logs \
    --dataloader_num_workers 4 \
    --remove_unused_columns false \
    --ddp_find_unused_parameters false

echo "✅ Training completed!"
echo "Check results in: $OUTPUT_DIR"
echo "View logs with: tensorboard --logdir ./logs"
