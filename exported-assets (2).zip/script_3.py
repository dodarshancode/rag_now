# Create a comprehensive training tracking and visualization system

tracking_script = '''#!/usr/bin/env python3
"""
Advanced Training Tracking and Visualization System
Provides comprehensive monitoring for LLaMA 4 fine-tuning without external dependencies
"""

import os
import json
import csv
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

class TrainingTracker:
    """Comprehensive training tracker with visualization capabilities"""
    
    def __init__(self, log_dir: str = "./logs", plots_dir: str = "./results/plots"):
        self.log_dir = Path(log_dir)
        self.plots_dir = Path(plots_dir)
        self.plots_dir.mkdir(parents=True, exist_ok=True)
        
        self.metrics_history = {
            'train_loss': [],
            'eval_loss': [],
            'learning_rate': [],
            'ce_loss': [],
            'syntax_loss': [],
            'semantic_loss': [],
            'parser_loss': [],
            'memory_usage': [],
            'throughput': []
        }
        
        # Setup logging
        self.logger = logging.getLogger('TrainingTracker')
        self.logger.setLevel(logging.INFO)
        
        if not self.logger.handlers:
            handler = logging.FileHandler(self.log_dir / 'tracking.log')
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
    
    def log_metrics(self, step: int, metrics: Dict[str, float]):
        """Log training metrics"""
        timestamp = datetime.now().isoformat()
        
        # Store in memory
        for key, value in metrics.items():
            if key in self.metrics_history:
                self.metrics_history[key].append({'step': step, 'value': value, 'timestamp': timestamp})
        
        # Log to file
        self.logger.info(f"Step {step}: {metrics}")
        
        # Save to CSV
        self._save_metrics_csv(step, metrics, timestamp)
    
    def _save_metrics_csv(self, step: int, metrics: Dict[str, float], timestamp: str):
        """Save metrics to CSV file"""
        csv_file = self.log_dir / 'training_metrics.csv'
        
        # Check if file exists to write header
        write_header = not csv_file.exists()
        
        with open(csv_file, 'a', newline='') as f:
            writer = csv.writer(f)
            
            if write_header:
                writer.writerow(['timestamp', 'step'] + list(metrics.keys()))
            
            writer.writerow([timestamp, step] + list(metrics.values()))
    
    def load_tensorboard_logs(self, tb_dir: str = None) -> Dict[str, List]:
        """Load metrics from TensorBoard logs"""
        if tb_dir is None:
            tb_dir = self.log_dir / 'tensorboard'
        
        tb_dir = Path(tb_dir)
        metrics_data = {}
        
        # Find all event files
        event_files = list(tb_dir.rglob('events.out.tfevents.*'))
        
        for event_file in event_files:
            try:
                ea = EventAccumulator(str(event_file))
                ea.Reload()
                
                # Extract scalar metrics
                for tag in ea.Tags()['scalars']:
                    scalar_events = ea.Scalars(tag)
                    
                    if tag not in metrics_data:
                        metrics_data[tag] = []
                    
                    for event in scalar_events:
                        metrics_data[tag].append({
                            'step': event.step,
                            'value': event.value,
                            'wall_time': event.wall_time
                        })
                        
            except Exception as e:
                self.logger.warning(f"Could not load {event_file}: {e}")
        
        return metrics_data
    
    def create_training_plots(self, save_plots: bool = True) -> Dict[str, plt.Figure]:
        """Create comprehensive training visualization plots"""
        
        # Load data from CSV if available
        csv_file = self.log_dir / 'training_metrics.csv'
        if csv_file.exists():
            df = pd.read_csv(csv_file)
        else:
            # Convert memory data to DataFrame
            all_data = []
            for metric_name, metric_data in self.metrics_history.items():
                for entry in metric_data:
                    all_data.append({
                        'metric': metric_name,
                        'step': entry['step'],
                        'value': entry['value'],
                        'timestamp': entry['timestamp']
                    })
            
            if not all_data:
                self.logger.warning("No training data available for plotting")
                return {}
            
            df = pd.DataFrame(all_data)
            df = df.pivot(index='step', columns='metric', values='value')
        
        figures = {}
        plt.style.use('seaborn-v0_8-darkgrid')
        
        # 1. Loss Components Over Time
        fig1, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig1.suptitle('Training Loss Components', fontsize=16, fontweight='bold')
        
        # Main losses
        if 'train_loss' in df.columns and 'eval_loss' in df.columns:
            axes[0,0].plot(df.index, df['train_loss'], label='Training Loss', linewidth=2)
            axes[0,0].plot(df.index, df['eval_loss'], label='Validation Loss', linewidth=2)
            axes[0,0].set_title('Overall Loss')
            axes[0,0].set_xlabel('Training Steps')
            axes[0,0].set_ylabel('Loss')
            axes[0,0].legend()
            axes[0,0].grid(True, alpha=0.3)
        
        # Custom loss components
        loss_components = ['ce_loss', 'syntax_loss', 'semantic_loss', 'parser_loss']
        available_components = [comp for comp in loss_components if comp in df.columns]
        
        if available_components:
            for i, component in enumerate(available_components):
                color = plt.cm.Set1(i)
                axes[0,1].plot(df.index, df[component], label=component.replace('_', ' ').title(), 
                             linewidth=2, color=color)
            
            axes[0,1].set_title('Custom Loss Components')
            axes[0,1].set_xlabel('Training Steps')
            axes[0,1].set_ylabel('Loss Value')
            axes[0,1].legend()
            axes[0,1].grid(True, alpha=0.3)
        
        # Learning rate schedule
        if 'learning_rate' in df.columns:
            axes[1,0].plot(df.index, df['learning_rate'], linewidth=2, color='purple')
            axes[1,0].set_title('Learning Rate Schedule')
            axes[1,0].set_xlabel('Training Steps')
            axes[1,0].set_ylabel('Learning Rate')
            axes[1,0].grid(True, alpha=0.3)
        
        # Memory usage
        if 'memory_usage' in df.columns:
            axes[1,1].plot(df.index, df['memory_usage'], linewidth=2, color='red')
            axes[1,1].set_title('Memory Usage')
            axes[1,1].set_xlabel('Training Steps')
            axes[1,1].set_ylabel('Memory (GB)')
            axes[1,1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_plots:
            fig1.savefig(self.plots_dir / 'training_losses.png', dpi=300, bbox_inches='tight')
        
        figures['training_losses'] = fig1
        
        # 2. Performance Metrics
        fig2, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig2.suptitle('Training Performance Metrics', fontsize=16, fontweight='bold')
        
        # Throughput
        if 'throughput' in df.columns:
            axes[0,0].plot(df.index, df['throughput'], linewidth=2, color='green')
            axes[0,0].set_title('Training Throughput')
            axes[0,0].set_xlabel('Training Steps') 
            axes[0,0].set_ylabel('Tokens/Second')
            axes[0,0].grid(True, alpha=0.3)
        
        # Loss convergence analysis
        if 'train_loss' in df.columns:
            # Moving average of loss
            window_size = max(50, len(df) // 20)
            moving_avg = df['train_loss'].rolling(window=window_size).mean()
            
            axes[0,1].plot(df.index, df['train_loss'], alpha=0.3, label='Raw Loss')
            axes[0,1].plot(df.index, moving_avg, linewidth=2, label=f'Moving Average (window={window_size})')
            axes[0,1].set_title('Loss Convergence')
            axes[0,1].set_xlabel('Training Steps')
            axes[0,1].set_ylabel('Training Loss')
            axes[0,1].legend()
            axes[0,1].grid(True, alpha=0.3)
        
        # Custom loss ratio analysis
        if all(comp in df.columns for comp in ['ce_loss', 'syntax_loss']):
            syntax_ratio = df['syntax_loss'] / (df['ce_loss'] + 1e-8)
            axes[1,0].plot(df.index, syntax_ratio, linewidth=2, color='orange')
            axes[1,0].set_title('Syntax Loss / CE Loss Ratio')
            axes[1,0].set_xlabel('Training Steps')
            axes[1,0].set_ylabel('Ratio')
            axes[1,0].grid(True, alpha=0.3)
        
        # Training stability (loss variance)
        if 'train_loss' in df.columns:
            window_size = max(50, len(df) // 20)
            loss_variance = df['train_loss'].rolling(window=window_size).std()
            
            axes[1,1].plot(df.index, loss_variance, linewidth=2, color='brown')
            axes[1,1].set_title('Training Stability (Loss Std Dev)')
            axes[1,1].set_xlabel('Training Steps')
            axes[1,1].set_ylabel('Standard Deviation')
            axes[1,1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_plots:
            fig2.savefig(self.plots_dir / 'performance_metrics.png', dpi=300, bbox_inches='tight')
        
        figures['performance_metrics'] = fig2
        
        # 3. Custom Loss Analysis
        if any(comp in df.columns for comp in loss_components):
            fig3, axes = plt.subplots(2, 2, figsize=(16, 12))
            fig3.suptitle('Custom Loss Function Analysis', fontsize=16, fontweight='bold')
            
            # Stacked area plot of loss components
            loss_data = df[[comp for comp in loss_components if comp in df.columns]].fillna(0)
            
            if not loss_data.empty:
                axes[0,0].stackplot(df.index, *[loss_data[col] for col in loss_data.columns],
                                  labels=loss_data.columns, alpha=0.7)
                axes[0,0].set_title('Loss Components (Stacked)')
                axes[0,0].set_xlabel('Training Steps')
                axes[0,0].set_ylabel('Cumulative Loss')
                axes[0,0].legend(loc='upper right')
                axes[0,0].grid(True, alpha=0.3)
            
            # Normalized loss components (percentage)
            if len(loss_data.columns) > 1:
                loss_percentages = loss_data.div(loss_data.sum(axis=1), axis=0) * 100
                
                for col in loss_percentages.columns:
                    axes[0,1].plot(df.index, loss_percentages[col], label=col, linewidth=2)
                
                axes[0,1].set_title('Loss Component Percentages')
                axes[0,1].set_xlabel('Training Steps')
                axes[0,1].set_ylabel('Percentage (%)')
                axes[0,1].legend()
                axes[0,1].grid(True, alpha=0.3)
            
            # Loss component correlation heatmap
            if len(loss_data.columns) > 1:
                correlation_matrix = loss_data.corr()
                
                im = axes[1,0].imshow(correlation_matrix, cmap='coolwarm', aspect='auto', vmin=-1, vmax=1)
                axes[1,0].set_title('Loss Component Correlations')
                axes[1,0].set_xticks(range(len(correlation_matrix.columns)))
                axes[1,0].set_yticks(range(len(correlation_matrix.columns)))
                axes[1,0].set_xticklabels(correlation_matrix.columns, rotation=45)
                axes[1,0].set_yticklabels(correlation_matrix.columns)
                
                # Add correlation values to heatmap
                for i in range(len(correlation_matrix.columns)):
                    for j in range(len(correlation_matrix.columns)):
                        axes[1,0].text(j, i, f'{correlation_matrix.iloc[i, j]:.2f}',
                                     ha='center', va='center', fontweight='bold')
                
                plt.colorbar(im, ax=axes[1,0])
            
            # Loss reduction over time (percentage improvement)
            if 'train_loss' in df.columns:
                initial_loss = df['train_loss'].iloc[:10].mean()  # Average of first 10 steps
                loss_reduction = ((initial_loss - df['train_loss']) / initial_loss) * 100
                
                axes[1,1].plot(df.index, loss_reduction, linewidth=2, color='darkgreen')
                axes[1,1].set_title('Training Progress (Loss Reduction %)')
                axes[1,1].set_xlabel('Training Steps')
                axes[1,1].set_ylabel('Loss Reduction (%)')
                axes[1,1].grid(True, alpha=0.3)
                
                # Add horizontal line at key milestones
                axes[1,1].axhline(y=50, color='orange', linestyle='--', alpha=0.7, label='50% Reduction')
                axes[1,1].axhline(y=75, color='red', linestyle='--', alpha=0.7, label='75% Reduction')
                axes[1,1].legend()
            
            plt.tight_layout()
            
            if save_plots:
                fig3.savefig(self.plots_dir / 'custom_loss_analysis.png', dpi=300, bbox_inches='tight')
            
            figures['custom_loss_analysis'] = fig3
        
        self.logger.info(f"Created {len(figures)} training plots in {self.plots_dir}")
        return figures
    
    def generate_training_report(self) -> str:
        """Generate a comprehensive training report"""
        
        # Load latest metrics
        csv_file = self.log_dir / 'training_metrics.csv'
        if not csv_file.exists():
            return "No training data available for report generation."
        
        df = pd.read_csv(csv_file)
        
        if df.empty:
            return "Training data is empty."
        
        # Calculate statistics
        total_steps = df['step'].max()
        latest_metrics = df.iloc[-1]
        
        # Calculate improvements
        initial_metrics = df.iloc[0] if len(df) > 0 else latest_metrics
        
        improvements = {}
        for col in ['train_loss', 'eval_loss']:
            if col in df.columns and col in latest_metrics:
                initial_val = initial_metrics[col] if col in initial_metrics else latest_metrics[col]
                final_val = latest_metrics[col]
                improvement = ((initial_val - final_val) / initial_val) * 100 if initial_val != 0 else 0
                improvements[col] = improvement
        
        # Generate report
        report = f"""
# LLaMA 4 Fine-tuning Training Report
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Training Summary
- **Total Training Steps**: {total_steps:,}
- **Final Training Loss**: {latest_metrics.get('train_loss', 'N/A'):.4f}
- **Final Validation Loss**: {latest_metrics.get('eval_loss', 'N/A'):.4f}

## Performance Improvements
"""
        
        for metric, improvement in improvements.items():
            if not pd.isna(improvement):
                report += f"- **{metric.replace('_', ' ').title()}**: {improvement:.2f}% improvement\\n"
        
        if 'throughput' in latest_metrics and not pd.isna(latest_metrics['throughput']):
            report += f"- **Final Throughput**: {latest_metrics['throughput']:.0f} tokens/second\\n"
        
        # Custom loss analysis
        if 'syntax_loss' in latest_metrics:
            report += f"""
## Custom Loss Components (Final Values)
- **Cross-entropy Loss**: {latest_metrics.get('ce_loss', 'N/A'):.4f}
- **Syntax Error Loss**: {latest_metrics.get('syntax_loss', 'N/A'):.4f}
- **Semantic Error Loss**: {latest_metrics.get('semantic_loss', 'N/A'):.4f}
- **Parser Structure Loss**: {latest_metrics.get('parser_loss', 'N/A'):.4f}
"""
        
        # Memory usage
        if 'memory_usage' in latest_metrics and not pd.isna(latest_metrics['memory_usage']):
            report += f"""
## Resource Utilization
- **Peak Memory Usage**: {latest_metrics['memory_usage']:.1f} GB per GPU
- **Memory Efficiency**: {(latest_metrics['memory_usage']/80)*100:.1f}% of A100 capacity
"""
        
        # Training recommendations
        report += f"""
## Training Analysis & Recommendations

### Convergence Assessment
"""
        
        # Check if losses are still decreasing
        if len(df) >= 100:
            recent_train_loss = df['train_loss'].iloc[-50:].mean() if 'train_loss' in df.columns else None
            early_train_loss = df['train_loss'].iloc[-100:-50].mean() if 'train_loss' in df.columns else None
            
            if recent_train_loss and early_train_loss:
                if recent_train_loss < early_train_loss:
                    report += "✅ **Training loss is still decreasing** - model is learning effectively\\n"
                else:
                    report += "⚠️ **Training loss has plateaued** - consider adjusting learning rate or training longer\\n"
        
        # Custom loss effectiveness
        if 'syntax_loss' in df.columns and 'ce_loss' in df.columns:
            syntax_ratio = df['syntax_loss'].iloc[-10:].mean() / (df['ce_loss'].iloc[-10:].mean() + 1e-8)
            
            if syntax_ratio > 0.5:
                report += "⚠️ **High syntax loss ratio** - consider reducing syntax_weight\\n"
            elif syntax_ratio < 0.05:
                report += "ℹ️ **Low syntax loss ratio** - consider increasing syntax_weight for better parser awareness\\n"
            else:
                report += "✅ **Balanced loss components** - custom loss is working effectively\\n"
        
        report += f"""
### Next Steps
1. **Model Evaluation**: Run comprehensive evaluation on test dataset
2. **Hyperparameter Tuning**: Experiment with loss weights if needed  
3. **Extended Training**: Consider additional epochs if loss is still decreasing
4. **Model Deployment**: Prepare model for inference if training objectives are met

---
*Report generated by LLaMA 4 Fine-tuning Framework*
"""
        
        # Save report
        report_file = self.plots_dir / 'training_report.md'
        with open(report_file, 'w') as f:
            f.write(report)
        
        self.logger.info(f"Training report saved to {report_file}")
        return report
    
    def export_metrics_for_analysis(self, format: str = 'csv') -> str:
        """Export all metrics for external analysis"""
        
        csv_file = self.log_dir / 'training_metrics.csv'
        if not csv_file.exists():
            return "No training data available for export."
        
        df = pd.read_csv(csv_file)
        
        if format.lower() == 'json':
            export_file = self.plots_dir / 'training_metrics.json'
            df.to_json(export_file, orient='records', indent=2)
        elif format.lower() == 'excel':
            export_file = self.plots_dir / 'training_metrics.xlsx'
            df.to_excel(export_file, index=False)
        else:  # Default to CSV
            export_file = self.plots_dir / 'training_metrics_export.csv'
            df.to_csv(export_file, index=False)
        
        self.logger.info(f"Metrics exported to {export_file}")
        return str(export_file)


def main():
    """Main function for running the tracker as a standalone script"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Training Tracker and Visualization')
    parser.add_argument('--log_dir', type=str, default='./logs', help='Log directory')
    parser.add_argument('--plots_dir', type=str, default='./results/plots', help='Plots output directory')
    parser.add_argument('--action', type=str, choices=['plot', 'report', 'export'], 
                       default='plot', help='Action to perform')
    parser.add_argument('--format', type=str, choices=['csv', 'json', 'excel'], 
                       default='csv', help='Export format')
    
    args = parser.parse_args()
    
    # Initialize tracker
    tracker = TrainingTracker(log_dir=args.log_dir, plots_dir=args.plots_dir)
    
    if args.action == 'plot':
        print("Creating training plots...")
        figures = tracker.create_training_plots(save_plots=True)
        print(f"Created {len(figures)} plots in {args.plots_dir}")
        
    elif args.action == 'report':
        print("Generating training report...")
        report = tracker.generate_training_report()
        print("Training report generated!")
        print("\\nReport preview:")
        print(report[:500] + "..." if len(report) > 500 else report)
        
    elif args.action == 'export':
        print(f"Exporting metrics in {args.format} format...")
        export_file = tracker.export_metrics_for_analysis(format=args.format)
        print(f"Metrics exported to: {export_file}")


if __name__ == "__main__":
    main()
'''

# Save the tracking script
with open('llama4_finetuning/src/utils/tracker.py', 'w') as f:
    f.write(tracking_script)

# Create a simple plotting utility script
plot_utility = '''#!/usr/bin/env python3
"""
Simple plotting utility for quick visualization during training
"""

import matplotlib.pyplot as plt
import pandas as pd
import sys
from pathlib import Path

def quick_plot(csv_file: str, output_dir: str = "./results"):
    """Create quick training plots from CSV file"""
    
    if not Path(csv_file).exists():
        print(f"Error: {csv_file} not found")
        return
    
    df = pd.read_csv(csv_file)
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)
    
    plt.style.use('seaborn-v0_8')
    
    # Simple loss plot
    fig, ax = plt.subplots(figsize=(10, 6))
    
    if 'train_loss' in df.columns:
        ax.plot(df['step'], df['train_loss'], label='Training Loss', linewidth=2)
    
    if 'eval_loss' in df.columns:
        ax.plot(df['step'], df['eval_loss'], label='Validation Loss', linewidth=2)
    
    ax.set_xlabel('Training Steps')
    ax.set_ylabel('Loss')
    ax.set_title('Training Progress')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_dir / 'quick_loss_plot.png', dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"Quick plot saved to {output_dir}/quick_loss_plot.png")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        quick_plot(sys.argv[1])
    else:
        quick_plot("./logs/training_metrics.csv")
'''

with open('llama4_finetuning/scripts/quick_plot.py', 'w') as f:
    f.write(plot_utility)

print("✅ Created comprehensive tracking and visualization system:")
print("   - src/utils/tracker.py (Advanced training tracker)")
print("   - scripts/quick_plot.py (Simple plotting utility)")

# Create a final summary of all created files
file_summary = """
# Created Files Summary

## Core Training Framework
- `scripts/train_distributed.py` - Main distributed training script with custom loss
- `scripts/setup_environment.py` - Automated environment setup
- `scripts/evaluate.py` - Model evaluation and analysis
- `launch_training.sh` - Production launch script

## Configuration Files  
- `configs/training_config.yaml` - Complete training configuration
- `configs/deepspeed_config.json` - DeepSpeed ZeRO-3 configuration
- `requirements.txt` - All Python dependencies

## Utilities and Tracking
- `src/utils/tracker.py` - Advanced training tracking and visualization
- `scripts/quick_plot.py` - Simple plotting utility
- `comprehensive_readme.md` - Complete documentation with mathematical details

## Directory Structure
```
llama4_finetuning/
├── src/
│   ├── models/       # Model definitions
│   ├── data/         # Data loading utilities  
│   ├── losses/       # Custom loss functions
│   └── utils/        # Tracking and utilities
├── configs/          # Configuration files
├── scripts/          # Training and utility scripts
├── data/            # Dataset storage
├── logs/            # Training logs and TensorBoard
├── checkpoints/     # Model checkpoints
└── results/         # Plots and evaluation results
```

## Key Features Implemented
✅ Production-grade distributed training setup
✅ Custom parser-aware loss functions with mathematical framework
✅ QLoRA integration with optimized memory usage
✅ DeepSpeed ZeRO-3 for 8x A100 GPU training
✅ Local training tracking (no W&B dependency)
✅ Comprehensive evaluation and visualization
✅ Air-gapped environment support
✅ Complete documentation with setup instructions
"""

print(file_summary)