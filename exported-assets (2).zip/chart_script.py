import plotly.graph_objects as go
import pandas as pd

# Create the data
data = [
    {"step": 0, "train_loss": 2.45, "eval_loss": 2.52, "ce_loss": 2.40, "syntax_loss": 0.35, "semantic_loss": 0.18, "parser_loss": 0.08, "lr": 0, "memory_gb": 62},
    {"step": 100, "train_loss": 2.12, "eval_loss": 2.18, "ce_loss": 2.05, "syntax_loss": 0.28, "semantic_loss": 0.15, "parser_loss": 0.06, "lr": 5e-5, "memory_gb": 64},
    {"step": 200, "train_loss": 1.89, "eval_loss": 1.95, "ce_loss": 1.82, "syntax_loss": 0.22, "semantic_loss": 0.12, "parser_loss": 0.05, "lr": 1e-4, "memory_gb": 65},
    {"step": 300, "train_loss": 1.71, "eval_loss": 1.78, "ce_loss": 1.65, "syntax_loss": 0.18, "semantic_loss": 0.09, "parser_loss": 0.04, "lr": 1e-4, "memory_gb": 66},
    {"step": 400, "train_loss": 1.58, "eval_loss": 1.64, "ce_loss": 1.52, "syntax_loss": 0.15, "semantic_loss": 0.08, "parser_loss": 0.03, "lr": 9.8e-5, "memory_gb": 67},
    {"step": 500, "train_loss": 1.47, "eval_loss": 1.53, "ce_loss": 1.42, "syntax_loss": 0.12, "semantic_loss": 0.06, "parser_loss": 0.03, "lr": 9.5e-5, "memory_gb": 65},
    {"step": 600, "train_loss": 1.39, "eval_loss": 1.45, "ce_loss": 1.35, "syntax_loss": 0.10, "semantic_loss": 0.05, "parser_loss": 0.02, "lr": 9e-5, "memory_gb": 66},
    {"step": 700, "train_loss": 1.33, "eval_loss": 1.38, "ce_loss": 1.29, "syntax_loss": 0.08, "semantic_loss": 0.04, "parser_loss": 0.02, "lr": 8.2e-5, "memory_gb": 64},
    {"step": 800, "train_loss": 1.28, "eval_loss": 1.33, "ce_loss": 1.25, "syntax_loss": 0.07, "semantic_loss": 0.04, "parser_loss": 0.02, "lr": 7.5e-5, "memory_gb": 65},
    {"step": 900, "train_loss": 1.24, "eval_loss": 1.29, "ce_loss": 1.21, "syntax_loss": 0.06, "semantic_loss": 0.03, "parser_loss": 0.01, "lr": 6.5e-5, "memory_gb": 66},
    {"step": 1000, "train_loss": 1.21, "eval_loss": 1.26, "ce_loss": 1.18, "syntax_loss": 0.05, "semantic_loss": 0.03, "parser_loss": 0.01, "lr": 5.8e-5, "memory_gb": 64},
    {"step": 1100, "train_loss": 1.19, "eval_loss": 1.24, "ce_loss": 1.16, "syntax_loss": 0.05, "semantic_loss": 0.02, "parser_loss": 0.01, "lr": 4.9e-5, "memory_gb": 65},
    {"step": 1200, "train_loss": 1.17, "eval_loss": 1.22, "ce_loss": 1.14, "syntax_loss": 0.04, "semantic_loss": 0.02, "parser_loss": 0.01, "lr": 4.1e-5, "memory_gb": 65},
    {"step": 1300, "train_loss": 1.15, "eval_loss": 1.21, "ce_loss": 1.13, "syntax_loss": 0.04, "semantic_loss": 0.02, "parser_loss": 0.01, "lr": 3.2e-5, "memory_gb": 64},
    {"step": 1400, "train_loss": 1.14, "eval_loss": 1.19, "ce_loss": 1.12, "syntax_loss": 0.03, "semantic_loss": 0.01, "parser_loss": 0.01, "lr": 2.5e-5, "memory_gb": 66},
    {"step": 1500, "train_loss": 1.13, "eval_loss": 1.18, "ce_loss": 1.11, "syntax_loss": 0.03, "semantic_loss": 0.01, "parser_loss": 0.01, "lr": 1.8e-5, "memory_gb": 65}
]

df = pd.DataFrame(data)

# Create the figure
fig = go.Figure()

# Add training loss line
fig.add_trace(go.Scatter(
    x=df['step'],
    y=df['train_loss'],
    mode='lines+markers',
    name='Train Loss',
    line=dict(color='#1FB8CD', width=3),
    marker=dict(size=8, color='#1FB8CD'),
    hovertemplate='Step: %{x}<br>Train Loss: %{y:.2f}<extra></extra>'
))

# Add validation loss line
fig.add_trace(go.Scatter(
    x=df['step'],
    y=df['eval_loss'],
    mode='lines+markers',
    name='Val Loss',
    line=dict(color='#DB4545', width=3),
    marker=dict(size=8, color='#DB4545'),
    hovertemplate='Step: %{x}<br>Val Loss: %{y:.2f}<extra></extra>'
))

# Update layout with dark theme
fig.update_layout(
    title='LLaMA 4 Training Monitor',
    xaxis_title='Training Step',
    yaxis_title='Loss',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    showlegend=True,
    plot_bgcolor='#1e1e1e',
    paper_bgcolor='#2d2d2d',
    font=dict(color='white', size=12),
    title_font=dict(size=16, color='white')
)

# Update traces
fig.update_traces(cliponaxis=False)

# Update axes with dark theme styling
fig.update_xaxes(
    showgrid=True,
    gridwidth=1,
    gridcolor='rgba(128,128,128,0.3)',
    tickcolor='white',
    linecolor='white',
    color='white'
)

fig.update_yaxes(
    showgrid=True,
    gridwidth=1,
    gridcolor='rgba(128,128,128,0.3)',
    tickcolor='white',
    linecolor='white',
    color='white'
)

# Save the chart
fig.write_image('llama4_training_monitor.png')